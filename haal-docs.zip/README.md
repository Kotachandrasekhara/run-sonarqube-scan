# H&M Advanced Analytics documentation portal

[![Build
Status](https://jenkins.haal.hm.com/buildStatus/icon?job=HAAL%2Fdocs%2Fmaster)](https://jenkins.haal.hm.com/job/HAAL/job/docs/job/master/)

## Summary

This is the repository hosting the source code of the HAAL docs portal,
referred to as `Docs`. The live version is available at
<https://docs.aa.hmgroup.com/>. `Docs` has the configuration and
instructions on how to generate the contents of the website from the
existing documentation of the use-cases. For example, styling and the
table-of-contents is defined in `docs`, but the **content** of the
documentation pages is created in the use-cases repositories. A
technical briefing is available [here](#Technical-notes).

## Goals

The main business-case for the portal is to reduce time spent in looking
for and sharing information related to the Advanced Analytics cases and
algorithms, by means of providing a unique, centralized, authoritative
repository for the high-level documentation of all AA initiatives at
H&M.

## Target group

The docs portal was created to serve primarily the following groups:

-   Stakeholders looking to familiarize themselves with Advanced
    Analytics at H&M. This includes technical and non-technical roles.

-   Technical roles who are joining a project, including but not limited
    to data scientists, data analysts and data engineers. The portal
    will provide the business background for a use-case, as well as the
    basic technical platform on which it was developed.

## How to access the portal

Access to the documentation portal is granted to all Advanced Analytics
use-cases by means of security groups. If you have questions about
access rights, please contact <haalsupport@hm.com>.

## Instructions for team members

The documentation portal can only be as useful as the output of the AA
projects. Adjustments are needed in the existing documentation in order
to make it more relevant for a broader audience.

If you are contributing to a code repository, here is what you can do to
make the project more valuable to more stakeholders:

-   Create a readme A good README is a requirement from day 1.\
    If your repository does not contain a README file, please add one
    now. Note: an empty readme doesn't count.

-   Double-check the source of the documentation for your area\
    If your documentation doesn't provide a good overview in the readme
    file, we kindly ask you to do so soon. Meanwhile, let us know which
    file to include in the `docs` portal (see below).

-   Review and improve The README should be legible and informative also
    for someone who's *not* working with the code. If your README is
    currently a deep-dive into your modules, refactor it by splitting
    the contents into more files.

## Technical notes

`Docs` is a Sphinx project, configured with the [Read the docs
theme](https://github.com/rtfd/sphinx_rtd_theme). The Sphinx source is
primarily the other Git repositories under Bitbucket HAAL project, which
are added to `docs` as
[submodules](https://git-scm.com/book/en/v2/Git-Tools-Submodules).
Publishing is done via Git to a Azure App Service.

If you would like to contribute to the documentation, please check
`Contributor Guidelines` in the docs site.

### Running the build locally

The `Docs` repository uses git modules to access documentation from other repositories.
To make sure you build documentation against the latest updates in other repos run

    git submodule update --init --recursive --remote

This will bring latest `master` branches of modules into file system.
To build the documentation locally run

    make clean html

### Generating PDF exports

Portions of the documentation can be exported in PDF format with a few manual steps.

    As of October 2019, it requires a version of a
    module not yet available in PIP. Add this entry to you requirements
    file:
    git+https://github.com/rst2pdf/rst2pdf.git@master#egg=rst2pdf

### Exporting as PDF

1. In `conf.py`, locate the variable `pdf_documents`, update with the relative path of the
document you want to export as PDF. For example, to export the Cookbook, set `pdf_documents` as below. Leave `project` as is.

    > pdf_documents = [('modules/haal/source/data-foundation-team-norms/cookbook', project, project, author), ]

2. Run `make pdf`
3. Check the output for potential errors.
4. Verify the output. The generated PDF will be located under `_build/pdf/`.






