:title: Documenting like a pro
:data-transition-duration: 1500

.. :css: hovercraft_custom.css


Documentation guidelines
========================

*Documenting like a pro*
------------------------

.. About "----": This is feature of hovercraft, "----" will delineate a step/slide.

----


.. Note: To generate a browsable, PPT-like presentation this page, run hovercraft -c source/_static/hovercraft.css source/modules/HAAL/documentation-guidelines.rst _build\presentation\doc_guidelines\

Principles
----------

- Technical documentation is an extension of your code base, and should be source-controlled
- A good readme file is a must, from day one, no exceptions
- PRs can only be accepted if it touched documentation  
- Documentation is published, easy to reach, easy to read

.. image:: assets/2018-10-24-12-33-40.png

----

From Markdown to RST
--------------------

- Markdown is OK for readme files, but has limitations  
    * Lack of a single standard, lack of extensibility 
    * Lack if semantic meaning (a clear separation between the content and how it is displayed)
- The preferred way to document your projects should be *reStructuredText* - the basics are very similar
- RST was specifically designed for writing technical documentation

----


reStructuredText and Sphinx
---------------------------

  
    *Sphinx is a tool that makes it easy to create* **intelligent** *and* **beautiful** *documentation*
    
.. Source: http://www.sphinx-doc.org/en/master/
    

----

Publishing your documentation
-----------------------------

- Sphinx outputs HTML, with a table-of-content  
- It requires initial configuration - well documented, we can help
- HAAL and use-cases have successfuly adopted RST and Sphinx to document
- A Jenkins pipeline fetches the latest changes and publishes it to Azure

----

What to document
----------------

- use in-code comments (i.e. Python docstrings)
- software dependencies, like Gurobi
- architecture
- configuration of HDInsight clusters
- data sources used
- Build process
- connectivity dependencies

----

A good readme
-------------

-  Lie in the root of you repository
-  Clear description of ownership of the repository
-  If from a HAAL Use Case, (at least) a executive summary of what it
   does
-  Purpose of the repository
-  Differentiation of the repository against others (if applicable)
-  Dependencies of this repository to any production or production-like
   environments (if applicable)
