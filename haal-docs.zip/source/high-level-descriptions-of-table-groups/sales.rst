Overview of tables on HDL covering sales data
=============================================
.. note:: WORK IN PROGRESS

**Contents**

.. contents::
        :local:


Sales on transaction level
--------------------------
Each day HDL imports sales transactions covering store and online sales from the H&M Datawarehouse called Biscuit (specifically CDW). These cover individual sales transactions that have information on 
	- sold items (variant-level), 
	- prices, 
	- discounts,
	- associated customers (varying data availabilty and differing customer identifications - see more in sections below)
	- cancellations (online)
	- returns (varying data availability - see more in sections below)
	- and more

**Time coverage**

Store sales are available from *2012/01* onwards, online sales from *2012/07*

Store
~~~~~
Store sales are available in `FACT.FT_RECEIPT_ROW`. 

**Granularity**

While the synthetic key `receipt_id` uniquely identifies a sales transaction (with `recept_no` being its natural counterpart), the composite key of `(receipt_id, receipt_row_id)` uniquely identifies a row within this transaction. Although it could be assumed, that each row within a sales transaction is grouped on an `article_id`-basis (with metrics like `sales_no_of_pieces` then being summed), this is not consistently the case and should be considered when designing metrics based on counts.

**Partitioning**

`FACT.FT_RECEIPT_ROW` is stored in partitions of `sales_date_id` (representing the date of a sales transaction) - to scan data efficiently, ensure you filter on this column.

**Data contents**

The table covers the global sales data of brands H&M, & other Stories, Monki, Weekday, ARKET, COS and Cheap Monday.



Online
~~~~~~
Online sales transactions are available in:
	- `FACT.FT_ONL_SALES_ORD_ITEM_LEGACY`: This covers online sales transactions received over the JOSHUA platform, as of November 2018, only Germany.
	- `FACT.FT_ONLINE_SALES_ORDER_ITEM`: This covers online sales transactions received over the GOE platform, as of November 2018, all markets except Germany.

**Important**: Data is available in each of the sources *up to the market specific platform transition date*. For example, given the Austria market switched on 2018-05-23, that means all online sales data up to this date is to be found within `FACT.FT_ONL_SALES_ORD_ITEM_LEGACY` and from that onwards only within `FACT.FT_ONLINE_SALES_ORDER_ITEM`. 

Further discount and payment information (GOE markets only) is covered in:
	- `FACT.FT_ONLINE_PAYMENT_METHOD`	
	- `FACT.FT_ONLINE_SALES_ORDER_DISCOUNT`
	- `FACT.FT_ONLINE_SALES_ORDER_DISCOUNT_ITEM`


Consolidated Sales
~~~~~~~~~~~~~~~~~~
`FACT.FT_ONLINE_STORES_SALES_CONSOL` offers a sales data consolidation that covers all online and store sales. It has been modeled after a comparable "omni-view" on Biscuit CDW which is called `p1_cdwetl.ft_sales_receipt_row` there.


Aggregated sales data
---------------------
-	`AGG.ONLINE_SALES_VARIANT <https://docs.aa.hmgroup.com/modules/haal/source/modules/HDL/docs/tables/agg/online_sales_variant/index.html>`_
-	AGG.ONLINE_SALES_GOE_VARIANT: Similar to AGG.ONLINE_SALES_VARIANT, but only GOE data. In fact it is a full input into AGG.ONLINE_SALES_VARIANT
-  `AGG.SALES_ARTICLE_LOCATION_DATE <https://docs.aa.hmgroup.com/modules/haal/source/modules/HDL/docs/tables/agg/sales_article_location_date/index.html>`_

Datamarts including sales data
------------------------------
-  `DMA.CUSTOMER_VIEW <https://docs.aa.hmgroup.com/modules/haal/source/high-level-descriptions-of-table-groups/customer_view.html>`_
	- DMA.CUSTOMER_SALES_WEEK
	- DMA.CUSTOMER_VIEW_SALES
