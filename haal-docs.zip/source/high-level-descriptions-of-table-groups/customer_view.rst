Overview of Customer View
=========================
.. note:: WORK IN PROGRESS

**Contents**

.. contents::
        :local:

Context
-------

    -   Customer View collects the customer data across various source systems to identify and analyze the customer behavior across various platforms such as transactional systems, interactions with promotional emails received by the customer and online browsing patterns.

    -   Initial discussion on Customer View started at June 2018. Customer View went live on September 2018 based on the request from the Personalization (Project ME) use-case team whose primary requirement is to target the customers with onsite personalization, using various Customer Journeys (such as: High Intent, Favorited Items, Post Purchase etc.)

    -   Customer View is mainly consumed by the Personalization and Promotion AI use-cases to derive the customer details like Sales Transactions and Online Behaviour etc.

Design
------

    -   Customer View is aggregated based on Business_Partner_Id and Country_Code, resulting in one row per the said combination for each calculation day (CALC_DATE) for which the table is refreshed for.

    -   The following types of customer IDs are presented through Customer View (in case of a N:1 relationship with Business_Partner_Id, they will be concatenated as a comma separated list):

            -   KNR - Swedish abbreviation for customer number/kund number
            -   BPID - Business_Partner_Id/SAP_Customer_NO - SAP CRM generated Customer Id.
            -   Club_Id - Retail Club Card number of the customer
            -   Customer_id - RDMS generated id.

    -   Currently neither golden record (relationship between KNR and BPID derived by SAS) or another customer reconciliation is being done for the customer view.

    -   Customer View is aggregated mainly based on ISO_WEEK which is derived from HDL Time Dimension. To know more about the concept of ISO weeks, see https://en.wikipedia.org/wiki/ISO_week_date. In the scope of this document, "week" refers to ISO week.

    -   Customer View attributes are suffixed with the components/source types i.e. email, sales, ga etc. And suffixed with weeks for which the data is aggregated i.e. 1W, 2W, 4W, 26W, 52W, 156W.
        And if its 26W, then including current week (0) and the previous 25 weeks data is aggregated to populate the metrics.

    - Mechanism of Customer View :

      .. image:: ../assets/Sample_CustomerView_HDL_Flow.JPG


    - Customer View Load Status : To know more about Customer View loading details, see https://app.powerbi.com/groups/8ca0c3b0-5fda-4693-ae8b-c9a3c22cbf86/reports/417d4d34-0724-4e7b-805b-9f6b3eb31692?ctid=30f52344-4663-4c2e-bab3-61bf24ebbed8).

Data Contents
-------------

    -   Customer View data is available for the countries NL, DK, SE, GB, PL, ES, FR and plan to scale up CH, FI, JP, NO, AT, BE, IT.

    -   Customer View is stored with CALC_DATE as partition and it only covers all Sundays in a year.

    -   Customer View is designed to have 156 ISO weeks of historic data for every CALC_DATE starting from 2017-07-01 to observe customer behaviour.

    -   Customer View will be refreshed every day from HDL, but it stores the data for the current week's Sunday thereby avoiding excessive storage of data and providing the entire week's data in a single CALC_DATE. 
        Also back-filling of Customer View is scheduled to run every Monday and Tuesday to refresh the partition of the previous Sunday to capture late arrivals.

Components and Sources of Customer View
---------------------------------------

Customer details are split across data sources such as transactional systems, email campaign and online site browsing etc.
Hence we target the four major data sources like Sales, Email, Core and Google Analytics and its related entities to derive Customer view.

Sales Data from H&M Transactional system Hybris which consolidates the transactional data for two different markets GOE and JOSHUA.
Email Data from Adobe Campaign's delivery logs data which consolidates the customers action and promotional emails sent details.
GA Data from Google Analytics feeds which captures the customer's online activity like adding/removing items to cart,transactions and every online sessions details.
Core contains basic customer geographic data from CRM system.

For Customer View, every components data is aggregated on a ISO_WEEK level separately for a customer and country. Later the weekly aggregated data is aggregated on 1W, 2W, 4W etc. which finally contributes in building the Customer View.


+------------------------------------------+---------------------------+----------------------------------------+
| Component                                | Key Data Sources          | HDL Table                              |
+==========================================+===========================+========================================+
| Customer Core Details                    | - SAS Member_Info         | - DIM.DIM_MEMBER_INFO                  |
|                                          | - Biscuit Business_Partner| - DIM.DIM_BUSINESS_PARTNER             |
|                                          | - Biscuit Customer        | - DIM.DIM_CUSTOMER_SYSID_EXTRACT       |
+------------------------------------------+---------------------------+----------------------------------------+
| Customer Segmentation Details            |- SAS OCES Segments        |- DIM.DIM_SEGMENT_MEMBERS               |
|                                          |                           |- DIM.DIM_SEGMENT_HIERARCHY             |
|                                          |                           |- STRUCT.CUSTOMER_SEGMENTS_MAPPING      |
+------------------------------------------+---------------------------+----------------------------------------+
| Customer Email Interactions              |- SAS Email Interaction    |- DIM.DIM_EMAIL_INTERACTION             |
|                                          |- AdobeCampaign Log Feeds  |                                        |
|                                          |      - BroadLog           |- FACT.AC_BROADLOG                      |
|                                          |      - ExcludeLog         |- FACT.AC_EXCLUDELOG                    |
|                                          |      - TrackingLog        |- FACT.AC_TRACKINGLOG                   |
|                                          |      - TrackingURL        |- FACT.AC_TRACKINGURL                   |
|                                          |      - Delivery           |- FACT.AC_DELIVERY                      |
|                                          |      - Operation          |- FACT.AC_OPERATION                     |
+------------------------------------------+---------------------------+----------------------------------------+
| Customer Online Behaviour                |- Google Analytics Feeds   |                                        |
|                                          |      - Sessions           |- FACT.GA_FAVORITES_SESSIONS            |
|                                          |      - Products           |- FACT.GA_FAVORITES_PRODUCTS            |
|                                          |      - Events             |- FACT.GA_FAVORITES_EVENTS              |
+------------------------------------------+---------------------------+----------------------------------------+
| Customer Sales Transactions              |- Store Sales              |- FACT.FT_ONLINE_STORES_SALES_CONSOL    |
|                                          |      - Receipt Row        |    - FACT.FT_RECEIPT_ROW               |
|                                          |- Online Sales             |                                        |
|                                          |      - GOE Sales          |    - FACT.FT_ONLINE_SALES_ORDER_ITEM   |
|                                          |      - Joshua Sales       |    - FACT.FT_ONL_SALES_ORD_ITEM_LEGACY |
+------------------------------------------+---------------------------+----------------------------------------+

Customer View ER Representation
-------------------------------

.. image:: ./../assets/Customer_View_ER.jpg

HDL Time Dimension
------------------

HDL Time Dimension(DIM.DIM_HDL_TIME) contains data from 2000-2029. Refreshed every midnight to adjust relative time spans.

Its Main Purpose is to map calendar day to ISO_WEEK and look up the logical time span of weeks.

Indicate logical week

    -   -1 :  next iso week
    -   0 :  current iso week
    -   1 :  last iso week

.. image:: ./../assets/HDL_Time_Dimension.JPG

Customer View Components
------------------------

Customer Core Details
_____________________

This part captures the customer details from CRM System which actually manages the customer's geographic and H&M Club registration details.

Data flow as follows:

    CRM --> Biscuit/CDW --> HAAL --> HDL

DMA.CUSTOMER_VIEW_CORE
~~~~~~~~~~~~~~~~~~~~~~

This datamart includes the customer identification number related attributes.

The main source tables are as follows:

    -   DIM.DIM_MEMBER_INFO
    -   DIM.DIM_CUSTOMER_SYSID_EXTRACT
    -   DIM.DIM_BUSINESS_PARTNER
    -   DIM.DIM_CUSTOMER

Table is populated with attributes which represents Favorites added, Sessions per sources like Google, Facebook, etc., Touchpoint details like Desktop,
Mobile, Android ,IOS etc. and Session Quality etc which are derived/aggregated based on the ISO_WEEK,Country and SAP Customer No ( BUSINESS_PARTNER_ID)

Customer Email Interactions
___________________________

This part captures the insight from the Adobe Campaign which sends promotional mails to the customer based on the personal Interest and purchase behaviour
and transforms into key metrics related to the customer's response to the emails received.

Data flow as follows:

    Adobe Campaign --> ICC --> HAAL --> HDL

DMA.CUSTOMER_EMAIL_WEEK
~~~~~~~~~~~~~~~~~~~~~~~

This DMA includes the customer's responses to the promotional emails sent through Adobe Campaign which are tranformed into key metrics.

The main source tables are as follows:

    -   DIM.DIM_EMAIL_INTERACTION

Table is populated with attributes which represents emails received, clicked and opened which are derived/aggregated based on the ISO_WEEK,Country and BUSINESS_PARTNER_ID

DMA.CUSTOMER_VIEW_EMAIL
~~~~~~~~~~~~~~~~~~~~~~~

This Datamart is aggregated table based on DMA.CUSTOMER_EMAIL_WEEK and aggregated weekly 1W,2W,4W,26W,52W and 156W.
Columns will be like EMAIL_COUNT_EMAILS_RECEIVED_1W,EMAIL_COUNT_EMAILS_RECEIVED_2W,EMAIL_COUNT_EMAILS_RECEIVED_4W,EMAIL_COUNT_EMAILS_RECEIVED_26W,
EMAIL_COUNT_EMAILS_RECEIVED_52W,EMAIL_COUNT_EMAILS_RECEIVED_156W etc

Customer Online Behaviour
_________________________

This part captures the insights from the customer's online browsing/search behaviour which is sourced from Google Analytics and transforms into the customer key metrics.

Data flow as follows:

    GOOGLE ANALYTICS --> BIG QUERY --> HAAL --> HDL

CustomerId Stitching
~~~~~~~~~~~~~~~~~~~~

CustomerId Stitching is prerequiste to integrate GA Data into Customer View.

FullvisitorId - It is the unique visitor ID/client ID generated on the client/browser and is stored in a cookie.It identifies the browser. A user can start several browsers on his computer and will get different FullvisitorId's for each of them.

Sessions      - A collection of hits/activities from the same user at a particular time.

CustomerID    - H&M's customer id connected to a session when the user has logged in.


*   Creating a table with only FullvisitorId(client_id i.e. unique per system brower ) and the CustomerId which is having maximum no. of relation/hits with the FullvisitorId. This logic is part of Data Integration of GA Feeds into HDL.
*   In Customer View, we always take the 6 months of data from GA feeds ( to populate everytime the refreshed customerid based on the logic derived above )and use the table created in the first step to populate customerid wherever the customerid is populated as NULL from the source based on the FullvisitorId.


DMA.CUSTOMER_GA_WEEK
~~~~~~~~~~~~~~~~~~~~

This datamart includes the customer online behaviour which is sourced from Google Analytics and integrated into HAAL through BigQuery.

The main source tables are as follows:

    -   FACT.GA_FAVORITES_SESSIONS
    -   FACT.GA_FAVORITES_PRODUCTS
    -   FACT.GA_FAVORITES_EVENTS

Table is populated with attributes which represents favorites added, sessions per sources like Google, Facebook, etc., Touchpoint details like Desktop,
Mobile, Android ,IOS etc. and Session Quality etc which are derived/aggregated based on the ISO_WEEK,Country and SAP Customer No ( BUSINESS_PARTNER_ID)

DMA.CUSTOMER_VIEW_GA
~~~~~~~~~~~~~~~~~~~~

This Datamart is aggregated table based on DMA.CUSTOMER_GA_WEEK and aggregated weekly 1W,2W,4W,26W,52W and 156W.
Columns will be like GA_FAVORITES_ADDED_COUNT_1W,GA_FAVORITES_ADDED_COUNT_2W,GA_FAVORITES_ADDED_COUNT_4W,GA_FAVORITES_ADDED_COUNT_26W,
GA_FAVORITES_ADDED_COUNT_52W,GA_FAVORITES_ADDED_COUNT_156W etc

Customer Sales Transactions
___________________________

DMA.CUSTOMER_SALES_WEEK
~~~~~~~~~~~~~~~~~~~~~~~

This datamart has store and online sales from consolidated sales transactions(Online and Store) table . These cover individual sales transactions both online and store.
It is used for customer view as one of the tables.The data is filtered on the H&M brand only.
The main source tables are as follows:

    -   FACT.FT_ONLINE_STORES_SALES_CONSOL
    -   DIM.DIM_MEMBER_INFO (CUSTOMER_ID,CLUB_ID,BUSINESS_PARTNER_ID etc)
    -   DIM.DIM_CUSTOMER_SYSID_EXTRACT (CUSTOMER_ID,CLUB_ID,BUSINESS_PARTNER_ID etc)
    -   STRUCT.GA_CATEGORIES (SKU,PRODUCT CATEGORY LEVEL)

Table is having information like sales transactions online/store counts,corresponding revenues,returned revenue etc which is being calculated for a given business_partner_id,country_code and ISO_WEEK
Metrices are calculated only for H&M brand specifically,besides having sales data ,it is also having data like member creation date (from dim_member_info),member club lifetime etc

**Time coverage**

Store sales are available from *2012/01* onwards, online sales from *2012/07*  -- todo


DMA.CUSTOMER_VIEW_SALES
~~~~~~~~~~~~~~~~~~~~~~~

    This Datamart is aggregated table based on DMA.CUSTOMER_SALES_WEEK and aggregated weekly 1W,2W,4W,26W,52W and 156W.
    Columns will be like SALES_TRX_CNT_1W,SALES_TRX_CNT_2W,SALES_TRX_CNT_4W,SALES_TRX_CNT_26W,SALES_TRX_CNT_52W,SALES_TRX_CNT_156W etc
