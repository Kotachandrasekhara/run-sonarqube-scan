Global Ranking
==============

.. note:: This documentation covers `HAAP-2997 ASQ Store Global Ranking <https://jira.hm.com/browse/HAAP-2997>`_.
   A very similar process with minor changes in scopes is followed for `ASQ Online Global Ranking <https://jira.hm.com/browse/HAAP-3205>`_

.. contents::
        :local:
        :depth: 1


Introduction
------------

The ASQ team needs global ranking for training data. The global ranking decoration data is a two-fold process.
Table below summarizes the steps as well as document the intermediate table names in HDL.

The preliminary implementation is in a
`Databricks notebook <https://northeurope.azuredatabricks.net/?o=844219618747099#notebook/1695609049515172/command/1695609049515176>`__


The Flow diagram depicts the steps involved in Global Ranking process.

.. image:: ../assets/global_ranking_flowchart.png

For columns of each table, see Appendix at the end of this document.

+--------+--------------------------------------------+----------------------------------------------------+------------------------------------------------+
| Step   | Description                                | Sub-step                                           | Table name                                     |
+========+============================================+====================================================+================================================+
|Step 1  | Generate the ground benchmarks             | 1.1  Rank by sales within a season                 | ASQ_STORE_GLOBAL_RANKING_SALESINSCOPE          |
|        |                                            +----------------------------------------------------+------------------------------------------------+
|        |                                            | 1.2  Quartile article selection for each department| ASQ_STORE_GLOBAL_RANKING_BENCHMARK_CANDIDATES  |
|        |                                            +----------------------------------------------------+------------------------------------------------+
|        |                                            | 1.3 Benchmark selection                            | ASQ_STORE_GLOBAL_RANKING_BENCHMARK             |
+--------+--------------------------------------------+----------------------------------------------------+------------------------------------------------+
|Step 2  | Generate the global rank value             | 2.1 Ranks agains benchmarks, with gap              | ASQ_STORE_GLOBAL_RANKING                       |
|        |                                            | 2.2 Final ranks, with gaps filled                  |                                                |
+--------+--------------------------------------------+----------------------------------------------------+------------------------------------------------+


Below we define how to perform each of these steps along with some general definitions. The output of every step should be saved in a separate table.

Global Ranking Decoration
-------------------------

The global ranking decoration data needed by ASQ requires two distinct
steps to be taken:

* Step 1: Generate the ground benchmarks 
* Step 2: Generate the global rank value 


Below we define how to perform each of these steps along with some
general definitions.

The output of every step should be saved in a separate table, which can help us to view the intermediate step results.

General definitions
^^^^^^^^^^^^^^^^^^^

 
* [G1] **PM scope** The planning market scope is defined as the following planning markets: 3,4,5,6,7,9,11,12,13,14,16,17,18,19,20,21,22,23,24,25,30,31,32,37,38,44,45,46,48,51,54,56,64,73,74,77
* [G2] **PS scope** The product season scope is defined as all product_season_ids greater than 53
* [G3] **Ground** The ground for a product season, obtained from `dim_product_season.ground_product_season`
* [G4] CC: The company currency, SEK
* [G5] **Assortment scope**: Any department having corporate_brand_id = 1

.. important: While ground season can in most cases be obtained by subtracting 2 from the product_season_id, logic on database identifiers is risky and highly discouraged.

The ground benchmarks need to be generated for every ground season for
all the seasons in the PS scope.

These are the distinct substeps of Step 1:

 * 1.1. The total SALES\_NET\_CC\_NSI ordering
 * 1.2. The quartile article selection for each department
 * 1.3. The (potentially overlapping) outlier article selection

Below we define each of these steps:

Step 1: substep 1.1 The total SALES\_NET\_CC\_NSI ordering
----------------------------------------------------------

For all seasons S such that they are ground [G3] to
any season in the PS scope [G2], select all articles belonging to the
assortment scope [G5] and sum their NET CC sales across the PM scope
[G1]. Group by the product season id and sort according to the
SALES\_NET\_CC\_NSI sum. Assign as column ``VALUE_RANK`` the order in
which each row occurs after the sorting. For instance if we have:

::

    article_id sales_net_cc_nsi
    12345 1000
    12346 500
    12347 399

we would expect article\_id 12345 to get the VALUE\_RANK 1, article\_id
12346 to get the VALUE\_RANK 2 and so on.

Step 1: substep 1.2 The quartile article selection for each department
----------------------------------------------------------------------

For each group output in substep 1.1 (i.e. product
season id group), divide the data into departments. Divide each
department into quartiles based on the SALES\_NET\_CC\_NSI (e.g. 0.25,
0.5, 0.75 are the cutoff points).

For every group (product season id, department\_id) select top 10
articles and the 10 lowest articles by ``VALUE_RANK``.

The ten most valuable articles (e.g. ``VALUE_RANK`` 1..10) The ten least
valuable articles (e.g. if there are 50 rows, it would be ``VALUE_RANK``
41..50) In addition to that, for every quartile per group (grouped by
product season id, department\_id), select a subset of the articles in
accordance with this logic:

For the first quartile (sales < 0.25), pick every third article. These
are the articles that sold the most. For the second quartile (0.25 <=
sales < 0.5), pick every fifth article. For the third quartile (0.5 <=
sales < 0.75 ), pick every 7th article. For the fourt quartile (0.75<=
sales), pick every 10th article. These are the articles that sold the
least. After the selection process only a subset of all the original
articles that we ranked in substep 1.1 should remain.


.. image:: ../assets/global_ranking_benchmark.png
   :scale: 70%

Step 1: substep 1.3 The (potentially overlapping) outlier article selection
---------------------------------------------------------------------------

Please note that there is an overlap between the
articles picked in substep 1.2, but we should never include an article
more than once. So if an article is picked more than once, just include
it one time (DISTINCT articles in each group).

Step 2: Generate global rank value For every season in the PS scope
-------------------------------------------------------------------

[G2], take all articles and sum up their SALES\_NET\_CC\_NSI value
across all planning markets in the PM scope [G1] grouped by season. Now,
for every season in the table above (referred to as the target season),
select the ground [G3] season data generated in Step 1 (i.e., the subset
of article output by Step 1 subset 1.3). So, if we have e.g. all
articles in season 60 and 59, we would pick ground data from step 1 for
season 58 and 57.

The ground data contains the ``VALUE_RANK`` column and the
SALES\_NET\_CC\_NSI column. The task is now to insert the articles from
the target season in the correct (read: ordered) place according to
SALES\_NET\_CC\_NSI. Example (one of the groups, i.e. a single target
product\_season\_id):

TARGET SEASON GROUP

::

    product_season_id article_id sales_net_cc_nsi
    60 123 1000
    60 124 500
    60 125 800

GROUND BENCHMARK GROUP (60 - 2 = season 58)

::

    product_season_id article_id sales_net_cc_nsi value_rank
    58 1001 2500 1
    58 1002 790 4
    58 1003 300 7
    58 1004 250 18
    58 1005 95 28

after merging these two and ordering by sales\_net\_cc\_nsi we get:

.. csv-table::
   :header: product_season_id,article_id,sales_net_cc_nsi,value_rank
    
    58,1001,2500,1
    60,123,1000,NULL
    60,124,800,NULL
    58,1002,790,4
    60,125,500,NULL
    58,1003,300,7
    58,1004,250,18
    58,1005,95,28

We now need to replace the NULL values regarding ``VALUE_RANK`` from the
target group. The rule for doing this is as follows:

1. A NULL value\_rank on a row that has no non-null value above it gets
   the lowest possible rank minus 0.5 for every row between it and the
   closest row that has a value\_rank. Example:

::

    product_season_id article_id sales_net_cc_nsi value_rank
    61 1234 2500 NULL
    59 832 1000 NULL
    59 824 800 5

Would become (notice how the top row gets 5 - 0.5 - 0.5):

::

    product_season_id article_id sales_net_cc_nsi value_rank
    61 1234 2500 4
    59 823 1000 4.5
    59 824 800 5

IMPORTANT: Ranks are allowed to be negative. This can happen when there
are more than two rows with NULL rank above a row with value\_rank 1.

2. A NULL value\_rank on a row that has no non-null values below it gets
   the highest possible rank plus 0.5 for every row between it and the
   closest row that has a value\_rank. Example:

::

    product_season_id   article_id  sales_net_cc_nsi  value_rank
    59                  1234        2500              85
    61                  832         1000              NULL
    61                  824         800               NULL

Would become (notice how the top row gets 5 - 0.5 - 0.5):

::

    product_season_id   article_id  sales_net_cc_nsi  value_rank
    59                  1234        2500              85
    61                  823         1000              85.5
    61                  824         800               86

3. If there are rows without value\_rank found between any two rows that
   have value\_rank, the rows with the missing value\_rank will get as
   rank the lowest of the ranks plus (high - low) / (N + 1) per row it
   has between itself and the lowest rank (where N is the number of NULL
   value\_rank rows found between the rows). Example:

   ::

       product_season_id   article_id  sales_net_cc_nsi  value_rank
       59                  1234        2500              85
       61                  832         1000              NULL
       61                  824         800               NULL
       59                  1235        600               120

   Would become (notice how the top row gets 5 - 0.5 - 0.5):

::

    product_season_id   article_id  sales_net_cc_nsi  value_rank
    59                  1234        2500              85
    61                  832         1000              96.66 [85 + 11.66, (120 - 85) / 3.0 = 11.66]
    61                  824         800               108.32 [85 + 11.66 + 11.66]
    59                  1235        600               120

Finally, the rows having a product\_season\_id that is equivalent to the
target season are selected and saved in the resulting table:

::

    product_season_id   article_id  sales_net_cc_nsi  value_rank
    61                  832         1000              96.66
    61                  824         800               108.32

We would also like to have the three most recent seasons updated daily,
if that is possible.


Appendix - Table descriptions
-----------------------------

ASQ_STORE_GLOBAL_RANKING_SALESINSCOPE
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. csv-table::
   :header-rows: 1

    "col_name","data_type"
    "ground_product_season_id","bigint"
    "article_id","bigint"
    "fiscal_ctry_id","bigint"
    "demdel_minus_returns_net_cc","double"
    "department_id","bigint"
    "product_season_id","bigint"


ASQ_STORE_GLOBAL_RANKING_BENCHMARK_CANDIDATES
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. csv-table::
   :header-rows: 1

    "col_name","data_type"
    "ground_product_season_id","int"
    "article_id","bigint"
    "fiscal_ctry_id","int"
    "demdel_minus_returns_net_cc","double"
    "department_id","bigint"
    "product_season_id","int"
    "value_rank","int"
    "n_tile","int"
    "row_count_top","int"
    "row_count_bottom","int"
    "top_10_bottom_10","boolean"
    "rank_in_tile","int"
    "first_quartile_pick","boolean"
    "second_quartile_pick","boolean"
    "third_quartile_pick","boolean"
    "fourth_quartile_pick","boolean"


ASQ_STORE_GLOBAL_RANKING_BENCHMARK
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. csv-table::
   :header-rows: 1

    "col_name","data_type"
    "ground_product_season_id","int"
    "article_id","bigint"
    "department_id","bigint"
    "demdel_minus_returns_net_cc","double"
    "n_tile","int"
    "rank_in_tile","int"
    "value_rank","int"
    "is_benchmark","boolean"
    "demdel_minus_returns_net_lag_1","double"
    "demdel_minus_returns_net_lead_1","double"
    "value_rank_lead_1","double"
    "hdl_load_id","bigint"
    "product_season_id","int"


ASQ_STORE_GLOBAL_RANKING
^^^^^^^^^^^^^^^^^^^^^^^^

.. csv-table::
   :header-rows: 1

    "col_name","data_type"
    "ground_product_season_id","int"
    "article_id","bigint"
    "fiscal_ctry_id","int"
    "demdel_minus_returns_net_cc","double"
    "department_id","bigint"
    "product_season_id","int"
    "value_rank","int"
    "n_tile","int"
    "row_count_top","int"
    "row_count_bottom","int"
    "top_10_bottom_10","boolean"
    "rank_in_tile","int"
    "first_quartile_pick","boolean"
    "second_quartile_pick","boolean"
    "third_quartile_pick","boolean"
    "fourth_quartile_pick","boolean"
