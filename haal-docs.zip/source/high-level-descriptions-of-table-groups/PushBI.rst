Overview of PushBI - HAAL Integration
=====================================

**Contents**

.. contents::
        :local:

Introduction
^^^^^^^^^^^^

PushBI Project captures the User actions on Push Messages sent to Customers through mobiles apps. The project delivered 
an analytics and reporting workspace for the end users, which will guide to take business decisions to improve the 
interactions with customers. The Push vision is to guide and give service to each customer throughout their shopping 
journey with spot-on communication in real-time, regardless if it’s online or in-store.

ExA Consumes the data from HAAL through Azure Data Factory.

**Security group:** HAAL UC PUSHBI

Requirement/Mapping
^^^^^^^^^^^^^^^^^^^

For all the Requirement specifications, please refer to `Requirement <https://hennesandmauritz.sharepoint.com/sites/Push30GEO-shared/Shared%20Documents/Forms/AllItems.aspx?csf=1&e=I2ghgu&cid=26bbbbc8-e075-4bba-9a99-048254fd6b4e&RootFolder=%2fsites%2fPush30GEO%2dshared%2fShared%20Documents%2f1%2e%20Launched%20to%20market%2f1%2e%20Requirements%2fPush%20BI%20report&FolderCTID=0x01200005DF3101D2A3B640AD9626812DBD39CF>`_


PushBI - HAAL Overview
^^^^^^^^^^^^^^^^^^^^^^

PushBI designed to integrate the Push notifications data from different source systems mentioned below.

📁 Internal HDL Tables
📱 PushBI Tables

.. |br| raw:: html

   <br />

.. csv-table::
    :header: "Source System >","ACS (Adobe Campaign Standard)","AAM (Adobe Audience Manager)","AEM (Adobe Experience Manager)","GA (Google Analytics)"
    :widths: 30, 100, 100, 100, 100

    "DAG","🕑5 AM UTC hdl_load_acs_partitioned_daily.py","🕑9 AM UTC  hdl_load_aam_partitioned_daily.py","🕑6 AM UTC hdl_load_aem_partitioned_daily.py","🕑9 AM UTC hdl_load_push_ga_partitioned_daily.py"
    "Tables","📁 FACT.ACS_APPSUBSCRIPTION FACT.ACS_BROADLOGS FACT.ACS_DELIVERYLOG","📁STRUCT.PUSH_BROWSING_SEGMENT 📱DIM.DIM_BROWSING_SEGMENT","📁DIM.AEM_PUSHMETADATA","📁FACT.INBOX_ACTIVITY FACT.NOTIFICATION_ACTIVITY"
    "Dependent Downstream DAG","Triggered DAG’s hdl_derived_push_acs_app_subscription.py hdl_derived_push_delivery.py","🕑9 AM UTC hdl_load_aam_partitioned_daily.py","🕑6 AM UTC hdl_load_aem_partitioned_daily.py","Triggered DAG’s hdl_derived_push_response.py"
    "Dependent Downstream Tables","📱DIM.DIM_APP_SUBSCRIPTION |br| 📱DIM.DIM_APP_SUBSCRIPTION_LOG  |br| 📱FACT.FT_APP_SUBSCRIPTION_ACTIVITY |br| 📱DIM.DIM_PUSH_DELIVERY  |br| 📱FACT.FT_PUSH_DELIVERY","📱STRUCT.PUSH_BROWSING_SEGMENT","📱DIM.DIM_PUSH_CONTENT_BLOCK","📱FACT.FT_PUSH_RESPONSE"


Architecture/Data Flow
^^^^^^^^^^^^^^^^^^^^^^

For Overall Architecture/Model details, please refer to `Architecture <https://hennesandmauritz.sharepoint.com/sites/Push30GEO-shared/Shared%20Documents/Forms/AllItems.aspx?csf=1&e=qsbTeG&cid=1250d13b-fdaa-4d3d-89b0-4fec5bf06a96&RootFolder=%2fsites%2fPush30GEO%2dshared%2fShared%20Documents%2f1%2e%20Launched%20to%20market%2f2%2e%20Architecture%2fPush%20BI%20report&FolderCTID=0x01200005DF3101D2A3B640AD9626812DBD39CF>`_


To understand the App -> ICC -> HAAL -> ExA -> Tableau flow, please refer to `Data Flow <https://hennesandmauritz.sharepoint.com/:u:/r/sites/Push30GEO-shared/_layouts/15/Doc.aspx?sourcedoc=%7BA60EFB7C-3028-4A72-9F76-4A9B5A5399BB%7D&file=Push%20Data%20Provisioning%20Overview.vsdx&action=default>`_

ACS
---

.. image:: ./../assets/Push-ACS-Flow.jpg

AAM
---

.. image:: ./../assets/Push-AAM-Flow.jpg

AEM
---

.. image:: ./../assets/Push-AEM-Flow.jpg

GA
--

.. image:: ./../assets/Push-GA-Flow.jpg

SAS
---

.. image:: ./../assets/Push-SAS-Flow.jpg

ACS Tables
^^^^^^^^^^

.. toctree::
   :titlesonly:
   :glob:

   ./../modules/haal/source/modules/HDL/docs/tables/fact/acs_appsubscription.rst
   ./../modules/haal/source/modules/HDL/docs/tables/fact/acs_broadlogs.rst
   ./../modules/haal/source/modules/HDL/docs/tables/fact/acs_deliverylog.rst
   ./../modules/haal/source/modules/HDL/docs/tables/dim/dim_app_subscription.rst
   ./../modules/haal/source/modules/HDL/docs/tables/dim/dim_app_subscription_log.rst
   ./../modules/haal/source/modules/HDL/docs/tables/fact/ft_app_subscription_activity.rst
   ./../modules/haal/source/modules/HDL/docs/tables/dim/dim_push_delivery.rst
   ./../modules/haal/source/modules/HDL/docs/tables/fact/ft_push_delivery.rst

GA Tables
^^^^^^^^^

.. toctree::
   :titlesonly:
   :glob:

   ./../modules/haal/source/modules/HDL/docs/tables/fact/inbox_activity.rst
   ./../modules/haal/source/modules/HDL/docs/tables/fact/notification_activity.rst
   ./../modules/haal/source/modules/HDL/docs/tables/fact/ft_push_response.rst

AAM Tables
^^^^^^^^^^

.. toctree::
   :titlesonly:
   :glob:

   ./../modules/haal/source/modules/HDL/docs/tables/struct/push_browsing_segment.rst
   ./../modules/haal/source/modules/HDL/docs/tables/struct/brg_push_browsing_segment_app.rst
   ./../modules/haal/source/modules/HDL/docs/tables/dim/dim_browsing_segment.rst

AEM Tables
^^^^^^^^^^

.. toctree::
   :titlesonly:
   :glob:

   ./../modules/haal/source/modules/HDL/docs/tables/dim/aem_pushmetadata.rst
   ./../modules/haal/source/modules/HDL/docs/tables/dim/dim_push_content_block.rst                                               
   

   

