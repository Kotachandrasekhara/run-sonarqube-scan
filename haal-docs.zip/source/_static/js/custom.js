function configureEmbeddedNotebooks(e) {
    let container = document.querySelector('.embedded-notebook');

    if(container==null || container.length === 0)
        return;

    var iframe = container.getElementsByTagName('iframe')[0];
    iframe.setAttribute('src', iframe.dataset.src);
    iframe.addEventListener(
        'load',
        function () {
            var iframe = this;

            setTimeout(function () {
                // Set height
                var loadableFrame = iframe.contentWindow.document.getElementsByClassName(
                    'overallContainer'
                )[0];
                var currentHeight = loadableFrame.scrollHeight;
                iframe.height = currentHeight + 10 + 'px';

                // Remove loading state
                container.classList.add('loaded');
            }, 100);
        },
        true
    );
}

function displayDevBanner() {
    if(!window.location.href.indexOf("azurewebsites.net") > -1)
        return;
    
    let content = "**** DEVELOPMENT version *****";
    let el = `<div class='banner-dev-slot'>${content}</div>`;
    let nav = document.querySelectorAll('nav');
 

    if(nav!==undefined && nav.length!==0)
        nav[0].insertAdjacentHTML("afterbegin", el);
}

// managing embedded notebooks
window.onload = e => {
    configureEmbeddedNotebooks(e);
    displayDevBanner();
};


