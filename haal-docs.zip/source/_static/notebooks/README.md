This folder will have HTML documents created during
the documentation build.

*** HTML files inside this folder are git-ignored!!! ***