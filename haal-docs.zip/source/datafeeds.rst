Data Feeds and Data Catalogue
=============================

An introduction to the main data sets and table groups in HAAL. To understand how you
can interact with HAAL data, see :doc:`data-understand-consume`.

Introduction
^^^^^^^^^^^^

Welcome to the HAAL Data Catalogue on docs portal. The purpose of this portal is to provide an overview of our data landscape at H&M to improve Data Literacy of our organization to ease Data Driven ,

The page is an introduction to the main data sets and table groups in HAAL.
To understand how you can interact with HAAL data, see Understanding and Consuming Data section.
Tables are categorized depending on the team that is responsible for the data domain, for example Group Customer Data is responsible HDL_CUSTOMER.

This categorization is an attempt to ease navigation & discovery of the many tables in HAAL while
learning about the teams that are handling the data you are interested in or are already using.

How to navigate the Data Catalogue:

- Click on the topic/area you want to learn more about. E.g, click on AI, Analytics & Data (AIAD) if you want to learn more about the AIAD Domain
- Click on the Team/Data Domain below to go to the tables under that team/data domain. E.g click on Team: Group Customer Data to see the HDL_CUSTOMER tables


If you have any suggestions on how to improve this Data Catalogue, please don’t hesitate to contact us.
You can write to: HAALsupport@hm.com


AI, AD Analytics & Data
^^^^^^^^^^^^^^^^^^^^^^^

.. figure:: assets/AIAD_logo.JPG
   :align: center





AIAD is made of **4 Product Areas**.

**Click** on each of them below to visit their specific Sharepoint Pages.


.. panels::

    `AI FOUNDATION <https://hennesandmauritz.sharepoint.com/sites/BTAIAnalyticsDataDomain/SitePages/AI-Foundation.aspx>`_

    *Improving decision making by providing data driven, forward looking insights for the H&M Group*

    ---
    `ANALYTICS & DATA PLATFORMS <https://hennesandmauritz.sharepoint.com/sites/AnalyticsDataPlatforms>`_

    *We enable teams and individuals to realise the full potential of data*

    ---
    `DATA FOUNDATION <https://hennesandmauritz.sharepoint.com/sites/BTAIAnalyticsDataDomain/SitePages/Data-Foundation.aspx>`_

    *We create, structure, guard and ensure data is available, understandable and of high quality*

    ---
    `OPERATIONS/RESPONSIBLE AI & DATA <https://hennesandmauritz.sharepoint.com/sites/BTAIAnalyticsDataDomain/SitePages/Operations-Responsible-AI-%26-Data.aspx>`_

    *We enable H&M Group to become a leader in building and using AI and data-driven products in a sustainable and ethical way*



HDL - HAAL Data Layer
^^^^^^^^^^^^^^^^^^^^^
An introduction to the main data sets and table groups in HAAL. To understand how you can interact with HAAL data, see Understanding and Consuming Data.

High level description of common table groups
In this section, we give introductory high-level overviews of common table groups that are present on HDL. The focus is  this section is long-term and broad, answering the most frequently asked questions (faq), in terms of data content, how data sources relate to each and how they are being derived.

Select specific  team pages below to see specific aspects of individual tables and their contents.

HAAL appreciates greatly any contributions related to errors or added content, that you think is relevant!

If you have any suggestions on how to improve this Data Catalogue, please don’t hesitate to contact us (include our dl lists here?)

There are currently 2 Data Foundation Teams that onboard & maintain the data available in HDL.

      **Click on the badges** :link-badge:`"<domain>",cls=badge-success text-white` or :link-badge:`"<domain>",cls=badge-info text-white` to land on the list of tables in the Domain.

.. panels::

    **Group Customer Data (GCD)**

    :link-badge:`https://docs.aa.hmgroup.com/modules/hdl-table-docs/hdl_customer/index.html, "Customer",cls=badge-success text-white`
    :link-badge:`https://docs.aa.hmgroup.com/modules/hdl-table-docs/hdl_pg_customer/index.html, "Customer New Integrations",cls=badge-success text-white`

    ---
    **Data Assets of Product Sales & Stock(DAPSS)**

    :link-badge:`https://docs.aa.hmgroup.com/modules/hdl-table-docs/hdl_master/index.html, "Master",cls=badge-info text-white`
    :link-badge:`https://docs.aa.hmgroup.com/modules/hdl-table-docs/hdl_product/index.html,"Product",cls=badge-info text-white`
    :link-badge:`https://docs.aa.hmgroup.com/modules/hdl-table-docs/hdl_price_promo/index.html, "Price&Promo",cls=badge-info text-white`
    :link-badge:`https://docs.aa.hmgroup.com/modules/hdl-table-docs/hdl_planning/index.html, "Planning",cls=badge-info text-white`
    :link-badge:`https://docs.aa.hmgroup.com/modules/hdl-table-docs/hdl_store_sales/index.html, "Store Sales",cls=badge-info text-white`
    :link-badge:`https://docs.aa.hmgroup.com/modules/hdl-table-docs/hdl_online_sales/index.html, "Online Sales",cls=badge-info text-white`
    :link-badge:`https://docs.aa.hmgroup.com/modules/hdl-table-docs/hdl_stock/index.html, "Stock",cls=badge-info text-white`
    :link-badge:`https://docs.aa.hmgroup.com/modules/hdl-table-docs/hdl_uc_asq/index.html, "ASQ",cls=badge-info text-white`
    :link-badge:`https://docs.aa.hmgroup.com/modules/hdl-table-docs/hdl_uc_allo/index.html, "Allocation",cls=badge-info text-white`


High level description of common table groups
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
In this section, we give introductory high level overviews of common table groups that are present on HDL. These overview pages answer the most frequent questions, in terms of data content, how data sources relate to each and how they are being derived. The focus of this section is long-term and broad - volatile and specific aspects of individual tables are covered in the next section.

HAAL appreciates greatly any contributions related to errors or added content, that you think is relevant!

.. toctree::
   :titlesonly:
   :glob:
   :maxdepth: 1

   high-level-descriptions-of-table-groups/**

Data Dictionary of HDL's derived tables
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
In this section, we cover short descriptions and actively maintained technical info (table keys, partitioning, ...) for all of HDL's derived tables - i.e. Datamarts, Aggregations or derived FACT/DIM data (like harmonization tables).

.. toctree::
   :titlesonly:

   modules/hdl-table-docs/index.rst

How can I request a new data feed
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

We implement new integrations to source systems according to business priorities and
following our sprint planning cycles.  The implementation of new data feeds follows
the same process as other activities, meaning that the first step is to create a
story or epic in JIRA. If you do not have the details of the integration yet, request a
short meeting with Half Scheidl to discuss the topic.

.. NOTE:: Go to `Jira <http://jira.hm.com>`_ to request a new HDL table or data feed, more instructions on the HAAL Support page

Where is the data coming from?
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Information regarding data ingestion can be retrieved `here <https://docs.aa.hmgroup.com/HAAL/modules/hdl_integrations/docs/haal-sources.html>`_.
