Guidelines to Azure Data Lake Storage Gen2 Migration
====================================================


‎Azure Data Lake Storage Gen2 is a set of capabilities dedicated to big data analytics,
built on Azure Blob storage. Data Lake Storage Gen2 is the result of converging the capabilities
of our two existing storage services, Azure Blob storage and Azure Data Lake Storage Gen1.
Features from Azure Data Lake Storage Gen1, such as file system semantics, directory, and
file level security and scale are combined with low-cost, tiered storage, high availability/disaster
recovery capabilities from Azure Blob storage. You can learn more about ADLS Gen2 `here <https://docs.microsoft.com/en-us/azure/storage/blobs/data-lake-storage-introduction>`_.

Currently all the usecases in the HAAL team shares the same datalake **haaldatalake** (Gen 1).


HDL in ADLS Gen2
~~~~~~~~~~~~~~~~

HDL data is currently available in both ADLS Gen1 and Gen2 storage layers.
HDL performs all the data processing in the ADLS Gen1 and replicating the data to ADLS Gen2 accounts
as soon as the data is available in ADLS Gen1. HDL will move its workload completely to ADLS Gen2 when
all the consumers are started reading from ADLS Gen2.

Below are the few points that usecases should know before accessing HDL data in ADLS Gen2 data.

* HDL has three different storage account for each of its environment.

    .. csv-table::
        :header: "HDL Environment", "ADLS Gen2 Path", "ADS Gen1 Path"
        :widths: 15, 50, 50

        "Development (DEV)", "abfss://**warehouse@devhdladl**.dfs.core.windows.net/<schema_name>/<table_name>", "adl://haaldatalake.azuredatalakestore.net/HDL/**DEV**/<schema_name>/<table_name>"
        "Integration (INT)", "abfss://**warehouse@inthdladl**.dfs.core.windows.net/<schema_name>/<table_name>", "adl://haaldatalake.azuredatalakestore.net/HDL/**INT**/<schema_name>/<table_name>"
        "Production (PRD)",  "abfss://**warehouse@prdhdladl**.dfs.core.windows.net/<schema_name>/<table_name>", "adl://haaldatalake.azuredatalakestore.net/HDL/**PROD**/<schema_name>/<table_name>"


* In ADLS Gen2, HDL database and table name in the path will be in **lower case**. We make this change because Spark creates the table location by default in lowercase.
    Eg:

    - ADLS Gen1: adl://haaldatalake.azuredatalakestore.net/HDL/PROD/**DIM/DIM_ARTICLE**

    - ADLS Gen2: abfss://warehouse@prdhdladl.dfs.core.windows.net/**dim/dim_article**

* We sync the user access along with the data. If a user has access to DIM/DIM_ARTICLE table in ADLS Gen1, then they will have the same access in ADLS Gen2 dim/dim_article.
  If we find any issues with the access, Kindly raise JIRA request in `HAAL Support Board`_ with the table name and usecases information.

* HDL Team ensures the data available in ADLS Gen2 has same level of quality and freshness as in ADLS Gen2.

* Firewall Settings: HDL ADLS Gen2 storage accounts will have additional level of security restrictions.
  The usecases can access HDL data only from the whitelisted networks. Eg: If the
  UC need to read HDL data from their Azure Databricks/AKS cluster, then you need to raise JIRA request
  in `HAAL Support Board`_ to enable accessing HDL datalake from the target resources.

* All the HDL ADLS Gen2 storage accounts are in **West Europe** region. So if usecases are consuming more data from HDL, then
  make sure your resources are in West Europe region. Else cross region data egress will cost a lot.

Usecases in ADLS Gen2
~~~~~~~~~~~~~~~~~~~~~

HAAL Team can help on the below request.

* To create new ADLS Gen2 storage account.
* To enable firewall whitelist between your storage account and Compute resources (AKS/Databricks/VM etc).
* To perform onetime data copy from ADLS Gen1 to ADLS Gen2.


Kindly raise a JIRA request in `HAAL Support Board`_ to get started with ADLS Gen2.

Databricks Global Init Script
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
A global init script runs on every cluster created in your workspace.
Global init scripts are useful when you want to enforce organization-wide library configurations or security screens.
Only admins can create global init scripts. You can create them using either the UI or REST API.

.. Important:: Use global init scripts carefully: It is easy to add libraries or make other modifications that cause unanticipated impacts. Whenever possible, use cluster-scoped init scripts instead. Any user who creates a cluster and enables cluster log delivery can view the stderr and stdout output from global init scripts. You should ensure that your global init scripts do not output any sensitive information.

Add a global init script using the UI
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
To configure global init scripts using the Admin Console:

+ Go to the Admin Console and click the Global Init Scripts tab.

  .. image::  assets/global-init-add.png

+ Click the + Add button
+ Name the script and enter it by typing, pasting, or dragging a text file into the Script field.

  .. image:: assets/global-init-scripts-tab.png
.. Note:: The init script cannot be larger than 64KB. If a script exceeds that size, an error message will appear when you try to save.

+ If you have more than one global init script configured for your workspace, set the order in which the new script will run.
+ If you want the script to be enabled for all new and restarted clusters after you save, toggle on the Enabled switch.

.. Important:: You must restart running clusters for changes to global init scripts to take effect, including changes to run order, name, and enablement state.

+ Click Add.

Edit a global init script using the UI
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
+ Go to the Admin Console and click the Global Init Scripts tab.
+ Click a script.
+ Edit the script.
+ Click Confirm

Migrate from legacy to new global init scripts
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
If your Azure Databricks workspace was launched before August 2020, you might still have legacy global init scripts. You should migrate these to the new global init script framework to take advantage of the security, consistency, and visibility features included in the new script framework.

+ Copy your existing legacy global init scripts and add them to the new global init script framework using either the UI or the REST API
Keep them disabled until you have completed the next step.
+ Disable all legacy global init scripts.
In the Admin Console, go to the Global Init Scripts tab and toggle off the Legacy Global Init Scripts switch

.. image:: assets/disable-legacy-global-init-scripts.png

+ Enable your new global init scripts.
On the Global Init Scripts tab, toggle on the Enabled switch for each init script you want to enable.

.. image:: assets/enable-global-scripts.png

+ Restart all clusters.

  - Legacy scripts will not run on new nodes added during automated scale-up of running clusters. Nor will new global init scripts run on those new nodes. You must restart all clusters to ensure that the new scripts run on them and that no existing clusters attempt to add new nodes with no global scripts running on them at all.
  - Non-idempotent scripts may need to be modified when you migrate to the new global init script framework and disable legacy scripts.

Useful links:
~~~~~~~~~~~~~

* `Access ADLS Gen2 from Databricks <https://docs.microsoft.com/en-us/azure/databricks/data/data-sources/azure/azure-datalake-gen2>`_
* `HAAL Team's ADLS Gen 2 Python SDK (built on top of official SDK) <https://dev.azure.com/HM-GROUP/HAAL-HDL/_packaging?_a=package&feed=haal-artifacts&view=overview&package=haal-azure-api&protocolType=PyPI>`_
* `Microsoft ADLS Gen 2 Python SDK<https://pypi.org/project/azure-storage-file-datalake/>`_
* `Global Init Scripts API <https://docs.microsoft.com/en-us/azure/databricks/dev-tools/api/latest/global-init-scripts>`_
.. _HAAL Support Board: https://hmgroup.atlassian.net/projects/XAIHAALS

