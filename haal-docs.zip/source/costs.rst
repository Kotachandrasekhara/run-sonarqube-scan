Platform Costs
==============

Use-cases can follow-up on their cloud platform consumption using the `HAAL Reporting Power BI app`_. Once you opened the HAAL Reporting App, follow the instructions on the Welcome page to switch to the 'Azure cost overview' report.

.. note:: Access to the report is based on security groups related to Advanced Analytics projects and use-cases.
          If you do not have access to the report, please contact HAAL at haalsupport@hm.com.


.. raw:: html

    <video controls autoplay loop style="max-width:100%">
     <source src="_static/HAAL_Cost_Reporting_Introduction.mp4#t=2" type="video/mp4">
        Your browser does not support the video tag.
    </video>


.. _HAAL Reporting Power BI app: https://docs.aa.hmgroup.com/reports
