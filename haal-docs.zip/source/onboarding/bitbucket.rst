Bitbucket access
================

.. important:: Bitbucket is managed by a central team at H&M, called Development Tools.
  The information below is applicable to the whole H&M group, and is provided for your
  convenience. For further assistance reach out to `developmenttools@hm.com <mailto:developmenttools@hm.com>`_

Related document:

 - :doc:`bitbucket-ssh`

You can request access to Bitbucket using the Self-Service portal!

1. Go to https://hm.service-now.com/selfservice/

.. image:: ../assets/selfservicebitbucket1.png

2. Search for "Bitbucket" and select the option that shows in the drop down.

.. image:: ../assets/selfservicebitbucket2.png

3. In the form, type "Granted via AD Group"

.. image:: ../assets/selfservicebitbucket3.png

4. Proceed with the request by clicking on Next, then Checkout.

5. You will receive notifications from ServiceNow when the request is complete.
  After that, you will be able to login in to Bitbucket.