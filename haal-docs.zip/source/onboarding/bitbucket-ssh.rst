Connecting to Bitbucket using SSH
=================================

All code repositories can be found at https://bitbucket.hm.com. Before you can clone to a local 
repository a few steps need to be completed.

.. note:: The instructions below are based on the official documentation `here <https://confluence.atlassian.com/bitbucket/set-up-an-ssh-key-728138079.html>`_ 
  In case of trouble, try reviewing the documentation first.

Generate a SSH key
------------------

An SSH key is needed before a clone of the BitBucket repository can be performed. To generate an SSH key, complete the
following steps:

	1. Open a terminal window
	2. Paste the following text into the window, but using your own email address:

		+ ssh-keygen -t rsa -b 4096 -C "your.email@example.com"

	3. An SSH key has now been created. The window will prompt you to save the key to a chosen location. Press Enter to
	accept the default location.
	4. No passphrase is needed (leave empty for no passphrase).


Add a key to Bitbucket
----------------------

To use your SSH key to clone the BitBucket repository, go to https://bitbucket.hm.com.  Login and go to your profile
('View profile'). Select Manage Account and then SSH keys. Click Add key and paste the key that has been generated into
the text box. Click Add key.


Cloning a repository using SSH
------------------------------

Navigate to the BitBucket repository intended for cloning using the search bar and selecting it in the repository list.
Go to the left-hand menu. Select Clone and then SSH from the drop-down menu that appears. Copy the string of text from
the window.

To finish the clone of the repository, open the terminal and navigate to the directory where you want to clone your
repository. Paste the command copied from BitBucket into the terminal and press Enter.

If the cloning was successful, a new directory should now appear inside the directory chosen for local repository.

Git
---

For version control within the IDE, Git integration should be utilised. For Git version control go to
https://git-scm.com/downloads and download the latest version for your operating system. Alternatively, it is possible
to follow the guide recommended by Atlassian accessible at https://www.atlassian.com/git/tutorials/install-git.
