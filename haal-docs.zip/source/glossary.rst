Glossary
========


.. glossary::

    CASTOR
      Here is the definition of CASTOR.

    Biscuit
      xxx


.. note:: Want to contribute? Send an email to haalsupport@hm.com