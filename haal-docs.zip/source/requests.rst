HAAL Support
============

For submitting a service request, bug or feature request to HAAL you
must create a new issue in our `HAAL Support Board <https://hmgroup.atlassian.net/jira/software/c/projects/XAIHAALS/boards/912>`_.
Read below what is needed before you can create issues, and how to submit service requests and feature
requests.

Once you submit an issue, you can communicate with the team by `writing comments to an issue <https://confluence.atlassian.com/jira063/commenting-on-an-issue-683542501.html>`_.
This is preferred to e-mail communication.


.. contents::
    :local:




Pre-requisites
^^^^^^^^^^^^^^
In order to use JIRA, you must have a functional H&M account. If you suspect
your account is not working, revisit the :doc:`activedirectoryaccount`,
or contact IT Help Desk. We also recommend you learn the basic of JIRA, for example by reading
`this article <https://confluence.atlassian.com/jirasoftwarecloud/working-with-issues-764478424.html>`_.

Other topics relevant to submission and follow-up of issues in JIRA:

- How to write a good story (what, why and how)

- Understand the story lifecycle:

- When does it start? When will it be finished?

- Is it in progress yet? Is it blocked? What does review mean?


New Service Requests
^^^^^^^^^^^^^^^^^^^^

1. Follow the link to HAAL Requests JIRA project
2. Hit the Create button
3. In Issue Type, choose **Task**

.. image:: assets/jira-haals-create-task.png

4. Fill-in the the following fields:

    **Summary**

    A brief introduction to your request. Think of it as the e-mail subject.

    **Description**

    What you would write in the body of an e-mail to HAAL.

5. After hitting save, add at least your project lead and a few of your
team members as watchers. See :ref:`watchers`.

New Feature Requests
^^^^^^^^^^^^^^^^^^^^

1. Discuss with your team and project lead before involving HAAL.

 - Ask yourself, do we understand well what we need?
 - Are we able to articulate the business benefit of the new feature?
 - Can we describe how this new feature relates to your project, and how
 it is going to be used?

2. Follow the link to HAAL Requests JIRA project
3. Hit the Create button
4. In Issue Type, choose **Task or Defect** as per need

.. image:: assets/jira-haals-create-story.png

5. Fill-in the the following fields:
    **Summary**

    A brief introduction to your request. Think of it as the e-mail subject.

    **Description**

    What you would write in the body of an e-mail to HAAL.

6. After hitting save, add at least your project lead and a few of you
team members as watchers.  See :ref:`watchers`.

New Bug or Defect report
^^^^^^^^^^^^^^^^^^^^^^^^

.. IMPORTANT::  Please avoid using e-mail to raise incidents to HAAL, and use JIRA instead.

Things to include (non-exhaustive):

- Description of the problem, include as much detail as you can spare

  + Context e.g. while running a query (please include the query)
  + Patterns e.g. only in PROD, only for planning market 7, always at 10PM, etc.
  + Affected components both at HAAL and UC end
  + Timing of incident and frequency (once, occasionally, consistently)
  + Logs, stack traces, etc.
  + ...

- Impact and urgency estimates
- Known workarounds (e.g. retry) and actions taken by your end to resolve the issue
- Similarities with prior incidents

.. NOTE:: The more detail you provide, the faster we will be able to resolve your incident



.. _watchers:

Tip: Adding watchers to a JIRA issue
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Watchers will receive notifications when an issue is updated.
By adding yourself as watcher, you can receive an email when a
story is started or finished.

To add a new watcher:

1. Open the issue in JIRA. If you know the issue number, you can also
type it in the top-right search box.

.. figure:: assets/jira-searching-issue.png


2. Once the issue loads, locate the watcher field.

.. image:: assets/jira-watchers.png

3. Click on the View Watchers button, a grey circle with a number inside.

4. In the dialog, search for the person name and once the name loads, click on it.
The number of watchers should increase by one.

.. image:: assets/jira-watchers-add.png
