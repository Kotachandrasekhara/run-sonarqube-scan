.. About documentation portal

About the Docs Portal
---------------------

The main business-case for the portal is to reduce time spent in looking
for and sharing information related to the Advanced Analytics cases and
algorithms, by means of providing a unique, centralized, authoritative
repository for the high-level documentation of all AA initiatives at
H&M.

Target group
^^^^^^^^^^^^

The docs portal was created to serve primarily the following groups:

    * Stakeholders looking to familiarize themselves with Advanced
      Analytics at H&M. This includes technical and non-technical roles.

    * Technical roles who are joining a project, including but not limited
      to data scientists, data analysts and data engineers. The portal will
      provide the business background for a use-case, as well as the basic
      technical platform on which it was developed.


What is included in the docs portal
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

-  Organization diagrams, role descriptions or people overview
-  Documentation about specific algorithms or use cases. Check
   individual repositories.
-  Documentation and “how-to” for tools or advanced analytics
   applications/user interfaces.


Build process
^^^^^^^^^^^^^

| ``Docs`` is a Sphinx project, configured with the `Read the docs
  theme <https://github.com/rtfd/sphinx_rtd_theme>`__. The source for the Sphinx build
  is primarily the other Git repositories under Bibucket HAAL project,
  which are added to ``docs`` as
  `submodules <https://git-scm.com/book/en/v2/Git-Tools-Submodules>`__.
  During build time, ``docs`` will update the submodules, and generate a
  static website. At the end of the build process, the output of the Sphinx
  is published to Azure App Service.
