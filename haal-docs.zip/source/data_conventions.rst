Data (Model) Conventions
========================

This page summarizes a set of best practices regarding data and data modelling. Both use cases and HAAL should follow these standards as much as possible.

Reasons for doing so it to ensure consistency across H&M, and esp. use cases, maximize accessibility for data consumers, prevent changes later on that might require refactoring, etc.

Below conventions are subdivided in multiple categories: naming of data assets, attribute naming and types incl. usage of prefixes and suffixes...

.. NOTE:: This is a WIP / placeholder page

****

Data Assets
-----------

**Naming Convention**

A pattern established by the HAAL team is the following:

- important clarifiers e.g. this is a snapshot
- channel e.g. online or sales
- entity or transaction type (in order of importance) e.g. customer or stock
- granularity on dimensions e.g. article or variant level detail
- other clarifiers e.g. indicate this is a view, e.g. indicate time period

Examples:

  - online_sales_variant
  - snapshot_store_stock_variant
  - customer_sales_week

  Although the exact order might not be a strict convention, think about including the above elements to ensure a unique and future-proof name.
  Additionally, avoid marginal abbreviations like *stk* for *stock*, *GA* for *Google Analytics* on the other hand is perfectly fine.
