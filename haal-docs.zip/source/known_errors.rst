Known Errors
============

This page summarizes known errors in data provisioned by HAAL. It is the responsibility of the use case to inspect this page, and apply fixes at their end.


These are known issue and cannot be fixed in the short run, mostly due to problems related to data acquisition. Therefore, escalating to HAAL will not help.
Providing a business case why such issues should be fixed can however help to put pressure and speed up resolution.

.. NOTE:: This is a WIP / placeholder page: please share your input with the AI Data Specialists


****

**Handling negative article_id**

Typically one should exclude all article_ids smaller than or equal to 0, i.e. only article_id > 0 are valid.


**enterprise_size_id is -1**

A sales of an item for which the size was not registered will show up in transactional tables with size -1. A possible workaround is to re-distribute these sales across the size curve.
A more worrying scenario is sales registrations with a wrong or different size, as these might go unnoticed. The latter is currently being investigated by AI Data Specialists.


**Misleading week_date_id**

Not a real error, though confusing: attributes like %_week_date_id often refer to the week ending on the mentioned date (with a week going from Sunday to Saturday).
Meaning that if you need to start doing something, e.g. apply shrink, starting on that week_date_id, then on a daily level you need to start the Sunday before i.e. subtract 6 days.


**ADLS Passthrough cluster error**
  + Error:
     - *com.databricks.backend.daemon.data.client.adl.AzureCredentialNotFoundException: Could not find ADLS Gen1 Token*

  + Workaround steps:
     - Open a new private browser
     - Login https://portal.azure.com
     - (Makesure that you have successfully passed MFA(Otp/Authenticator))
     - In New Tab Login https://westeurope.azuredatabricks.net/workspaceurl
