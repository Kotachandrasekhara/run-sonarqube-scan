Security
========

Security Guidelines
-------------------

-  **Never** expose any service to the public Internet without approval
   from HAAL platform team
-  Any service hosted on HAAL infrastructure **must** be protected by 
   authentication (preferably MFA)
-  **All** passwords should be 12+ characters with a mix of lower/upper
   alphanumerics and symbols
-  Shared credentials must be encrypted and stored safely (e.g. password
   protected or using Azure Key Vault)
-  Shared credentials **must** be rotated whenever someone rolls off a
   team

Physical security at the BCG office
-----------------------------------

When working at our partner's premises make sure to familiarize yourself with their office rules, including off-limits area.
It is important to remember these guidelines:

* **Never open doors for anyone without a valid key card to the office**. If in doubt, you may reach out to the BCG reception (+46 8 402 4400 or +46 73 079 4500)
* If you notice any suspicious activity and/or any suspicious person, please call Helena Stjernevall (+46 73-079 44 56) or Ludwig Baat (+46 73-079 44 59), or the Police 112.
* For your safety, the security company, Nokas, that patrols the building off office hours, is authorized to ask for names and identity cards of anybody at the office


Azure Key Vault
---------------

Azure Key vault is designed to support application keys and secrets. Key
Vault is not intended to be used as a store for user passwords. Azure
Key Vault can help you securely store and manage application secrets.

For more info on Azure Key Vault see the
`documentation <https://docs.microsoft.com/en-us/azure/key-vault/>`__.

Also check out this
`example <https://azure.microsoft.com/en-us/resources/samples/app-service-msi-keyvault-python/>`__
on how to use Key Vault in Python with Managed Service Identity.

NOTE! Azure Key vault is designed to support application keys and
secrets. Key Vault is **not** intended to be used as a store for user
passwords.


VM Patching
---------------
Please refer to this `report <https://app.powerbi.com/groups/ef3e2769-7d65-43d9-a7a5-46b9c7106728/reports/5ecac3f4-6fd7-46c1-a9bd-7e6e625189ae/ReportSectionad64013977034603e568>`_ for patch compliance of your VMs.

Auto patching for your VMs has been enabled, and will run the 2nd Sunday of every month. Per UC lead request, some VMs have been excluded from auto patching. We recommend to still patch these VMs on a monthly basis.
