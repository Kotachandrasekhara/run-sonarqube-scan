.. This document was initially converted from a PDF file available in the intranet.

Self Service Password Reset
===========================

Self-service password reset enables you to reset your own password
without the need to call Global Help Desk. To be able to use the service you must
have Multi-factor Authentication enabled and you must register for self-service
password reset.

.. contents::
        :local:


Registration for self-service password reset
--------------------------------------------
1. You will need to set up Multi Factor Authentication (MFA) to register
for Self Service Password Reset. Detailed instructions and more
information regarding MFA can be found
:download:`here <assets/Guide - Set up Multi-Factor Authentication.pdf>`.

2. You can register for Self Service Password Reset by visiting
https://myapps.microsoft.com. Click on your name in the upper right corner
and go to "Profile". Under Manage your account you click on "Set up
self service password reset".

|image0|

3. The registration for Self Service Password Reset will then start. The
authentication method you registered for MFA will be suggested by
default.

|image1|

4. If you are satisfied with the default authentication method, click
"Verify".

Otherwise click on "Set it up now" You must choose at least one of
the two suggested alternative authentication methods.

5. "If choosing" Authentication Phone" you will be asked to register an
authentication phone number. To this number you will be able to
receive, depending on your choice, either a verification code in text
or as a phone call.

|image2|

On next page the you will enter the verification code and click
"Back" to get back to the registration page.

|image3|

The process for adding an authentication e-mail address is similar, a
verification code is sent out to the e-mail address given instead.

When back on the main page you shall click "Finish" and the
registration is ready.


Resetting your password
-----------------------

If you have forgotten your password, you can easily reset the
password by using the Self Service Password Reset functionality

To reach to the service, use this url:
`https://passwordreset.microsoftonline.com?whr=hm.com <https://passwordreset.microsoftonline.com/?whr=hm.com>`__

|image4|

1. Enter your User-ID in the field and then the characters shown in the
picture in the field and click "Next".

2. You can now choose which of the registered contact methods you want
to use for verification.

If choosing "Text my Mobile phone", you will be asked to enter your
phone number. The last 2 digits of the registered phone number will
be shown as a hint. Then just click Text.

|image5|

3. A text message will be sent to the registered phone containing a
verification code.

|image6|

You will then enter the verification code and click "Next".

If using e-mail my alternative email or call my mobile phone, the
process is similar with a verification code sent out and you will be
asked to enter the code and click Next.

4. Now you will be able to enter a new password and confirm it. When
you click "Finish" the service will validate the new password toward
H&M’s password policy and if it complies, the new password will be
set.

|image7|

The process is ready; you will be informed about that the reset was
successful and can now start to use your new password.

|image8|

As a security measure, you will also receive a notification mail
about the change.

|image9|

.. |image0| image:: assets/media/image1.jpg

.. |image1| image:: assets/media/image2.jpg

.. |image2| image:: assets/media/image3.jpg

.. |image3| image:: assets/media/image4.jpg

.. |image4| image:: assets/media/image5.jpg

.. |image5| image:: assets/media/image6.jpg

.. |image6| image:: assets/media/image7.jpg

.. |image7| image:: assets/media/image8.jpg

.. |image8| image:: assets/media/image10.jpg

.. |image9| image:: assets/media/image11.png
