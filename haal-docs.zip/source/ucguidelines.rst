Use Case Guidelines
===================

Development Process
-------------------

These are the requirements for a use case in production.

- All source code and algorithms **must** be version controlled
  Documented branching strategy, e.g. Gitflow
- Do code reviews, ideally enforced using pull request to merge.
- Do CI/CD with automated unit and integration testing
- Do automated code quality controls


Target Solutions
----------------

These are the preffered solutions, any exceptions is evaluated case by case.

- For Version control use Bitbucket, see :doc:`/modules/haal/source/modules/devops/bitbucket/index`.
- For Project Management use Jira.
- For Continuous Integration use Jenkins.
- For Code Quality control use SonarQube.
- For Workflow orchestration use Airflow.
- For Containerization use Kubernetes/Docker.
- For Data Processing use Spark & Hive (HDInsight/Databricks)
- For Documentation use Sphinx, see :doc:`documentation-guidelines`.

Guiding Principles
------------------

- Python is the preferred language for algorithms
- Adhere to the single responsibility principle
  Pure functions is a deterministic operation without side-effects.
- Immutable and idempotent data pipelines
  Use a workflow orchestration tool like Airflow
- Pets vs Cattle, use infrastructure as code
- Separation of compute and storage
  Store your data in the lake *not* locally on VMs or clusters


If you have any questions don't hesitate to contact HAAL Support.
