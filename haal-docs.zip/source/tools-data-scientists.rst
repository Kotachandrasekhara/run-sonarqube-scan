Tools for data scientists
=========================

.. TIP: See also - :doc:`Devops Tools <../jenkins/README>`

.. contents::
        :local:

Data Science Virtual Machine
^^^^^^^^^^^^^^^^^^^^^^^^^^^^
The Data Science Virtual Machine (DSVM) is a customized VM image on Microsoft’s Azure cloud built specifically for doing data science.
It has many popular data science and other tools pre-installed and pre-configured to jump-start building intelligent applications for
advanced analytics. It is available on Windows Server and on Linux.

For more info check out the `DSVM documentation <https://aka.ms/dsvmdoc>`_.

Gurobi
^^^^^^
Gurobi is an optimization solver available to the UCs via the cloud. More information here: :doc:`/modules/haal/source/Tutorials/gurobi`

Jupyter
^^^^^^^

Jupyter is by default installed both on the `HDInsight Spark <https://docs.microsoft.com/en-us/azure/hdinsight/spark/apache-spark-jupyter-notebook-kernels>`_ clusters and the DSVMs.


Spark
^^^^^

- :doc:`/modules/haal/source/Tutorials/Spark/Readme`  `[Get the Jupyter notebook] <http://bitbucket.hm.com/projects/HAAL/repos/haal/browse/source/Tutorials/Spark/GettingStartedSpark.ipynb>`_

Databricks
^^^^^^^^^^

Resources:

- `Azure Databricks docs <https://docs.azuredatabricks.net>`__
- Connectivity from Python for Linux: :doc:`/modules/haal/source/modules/HDL/hdl/databricks/databricks_odbc_setup`


Connectivity from Alteryx, Tableau, Excel, etc. for Windows
-----------------------------------------------------------

1. Request Databricks access via `HAALSupport <mailto:HAALsupport@hm.com>`_, skip this step if you already have access
2. Browse to `Databricks <https://northeurope.azuredatabricks.net/>`_ and login with your H&M credentials
3. Get an access token, please follow this guide: `Token Management <https://docs.azuredatabricks.net/api/latest/authentication.html#token-management>`_
4. Follow the first part of this guide: `Set up a DSN <https://docs.microsoft.com/en-us/azure/azure-databricks/connect-databricks-excel-python-r>`_, this will require you to install the `Simba Spark ODBC driver <https://databricks.com/spark/odbc-driver-download>`_
5. Switch to your preferred tool

  - For Alteryx: drag in the 'Input data' tool, under 'File or Database' choose 'Other Database' then 'ODBC'
  - For Tableau: in the Connect screen, choose 'More' under 'To a Server' then 'Other Databases (ODBC)'
  - For Excel, Python or R: refer to step 4

6. In the ODBC connection screen choose the DSN you just created, named 'MyAzureDatabricks_DSN' if you followed above steps to the letter
7. For Alteryx or Tableau: you will be requested to choose one or multiple tables, or to write some SQL
