.. H&M xAI Documentation documentation master file, created by
   sphinx-quickstart on Mon Jun  4 14:18:59 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Introduction
============

Welcome to the documentation portal of H&M Advanced Analytics (AA),
which we also call the **docs portal**. The purpose of this portal is to provide an
overview of advanced analytics at H&M, and details of each AA project or use-case. The
portal also has a dedicated area for `HAAL <modules/HAAL/source/>`_, the technology core of
H&M AA. We intend to make the content useful to a hybrid audience, including data analysts,
project leads, data engineers and data scientists. If you new to H&M AA, we suggest
you read first the contents on the left of this page, and then proceed to more in-depth
information about each of the areas below.

.. Note: Toc tree uses content from various folders and repositories.


.. table::
   :class: noborder

   +----------------+----------------+---------------+
   | |icon_Allo|    | |icon_ASQ|     | |icon_PERSON| |
   +----------------+----------------+---------------+
   | |icon_MDS|     | |icon_MDO|     | |icon_FF|     |
   +----------------+----------------+---------------+
   | |icon_ASQO|    |                |               |
   +----------------+----------------+---------------+
   |                  |icon_AIFOUN|                  |
   +----------------+----------------+---------------+
   |                  |icon_HAAL|                    |
   +----------------+----------------+---------------+



Note: you might need a different set of permissions to browse the documentation areas above.

.. |icon_Allo| image:: assets/AA_Icons_Allo.png
                        :target: notavailable.html
                        :class: hover01


.. |icon_ASQ| image:: assets/AA_Icons_ASQ.png
                        :target: https://prdasqfreapp01.azurewebsites.net
                        :class: hover01


.. |icon_ASQO| image:: assets/AA_Icons_ASQO.png
                        :target: https://prdaolfreapp01.azurewebsites.net/introduction.html
                        :class: hover01


.. |icon_MDS| image:: assets/AA_Icons_MDS.png
                        :target: https://prdmdsfreapp01.azurewebsites.net
                        :class: hover01


.. |icon_MDO| image:: assets/AA_Icons_MDO.png
                        :target: https://prdmdodocapp01.azurewebsites.net
                        :class: hover01


.. |icon_HAAL| image:: assets/AA_Icons_HAAL.png
                        :target: /HAAL/index.html
                        :class: hover01


.. |icon_FF| image:: assets/AA_Icons_FF.png
                        :target: notavailable.html
                        :class: hover01


.. |icon_PERSON| image:: assets/AA_Icons_PERSON.png
                        :target: https://prdrecfreapp01.azurewebsites.net
                        :class: hover01

.. |icon_AIFOUN| image:: assets/AA_Icons_AI_Foundation.png
                        :target: https://prdxaifreapp01.azurewebsites.net/
                        :class: hover01

.. toctree::
   :hidden:
   :maxdepth: 2
   :caption: H&M Advanced Analytics

   Introduction<self>
   Advanced Analytics UCs <usecases>
   Getting Started <getting-started>
   activedirectoryaccount

.. toctree::
   :hidden:
   :maxdepth: 2
   :caption: Self-service catalogue

   Release Notes<modules/haal/source/releases>
   Raise a request<requests>
   Raise an Incident <incidents>
   Platform Costs<costs>
   glossary


.. toctree::
   :hidden:
   :maxdepth: 1
   :caption: Data Wiki

   Consume Data<data-understand-consume>
   Data Catalogue<datafeeds>
   notebooks
   Data Conventions<data_conventions>
   Data Quality<modules/haal/source/modules/HDL/docs/general/data_quality.rst>
   Known Errors<known_errors>

.. toctree::
   :hidden:
   :maxdepth: 2
   :caption: Advanced Analytics Playbook

   ucguidelines
   security
   GDPR
   Documentation Guidelines<documentation-guidelines>
   Tools<tools-data-scientists>
   ADLS Gen 2 Migration Guidelines<adls-gen2-migration>


.. toctree::
   :hidden:
   :maxdepth: 2
   :caption: About

   About the Docs<about>
   contributor-guidelines


.. toctree::
.. :maxdepth: 3
.. :caption: Advanced analytics use cases

.. Assortment quantification (ASQ)<modules/assortment/doc/source/business_logic/ASQ.rst>
.. Allocation <modules/allo/docs/business-logic>
.. Markdown stores<modules/store_markdown/documentation/getting-started>
.. Markdown online<modules/online_markdown_production/README>
.. modules/trend_detection/TrendDetection/README
.. modules/index
