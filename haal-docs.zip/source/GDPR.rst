GDPR
====


.. note:: TL;DR

   Any new use-cases and/or data exports needs to be approved! Send all requests/complaints to `Ulf Collin <mailto:ulf.collin@hm.com>`__.

GDPR in practice
----------------

The introduction of GDPR affects the way we work with personally identifiable information (PII).

- It is not only the data that we to protect, but also how we use of the data.
      Our customers provide us their data under a specific consent, which the use needs to be aligned with. In some cases, this is really easy to determine,
      e.g. if we’re talking about improving already existing processes where the PII is already used (like product reco, personalized promo). For new types
      of analysis/use-cases outside what we already do, it becomes more complex to determine if this new use is aligned with the consent, and for those
      cases we might need to involve the GDPR office and the Legal team.

- The approval of how we use the data is not done by any business manager, it’s done by the Data Privacy Coordinator (DPC) in each function
      The DPC for each function can be found `here <https://hennesandmauritz.sharepoint.com/sites/GDPR/Pages/Data-Privacy-Coordinators-Central-Functions.aspx>`_.
      It is the responsibility of the different DPCs to ensure that any use of GDPR data follows the H&M rules.

- The GDPR legislation is not tried in court yet…
      Today no one really knows how hard the penalties will be for violations, but the capped penalty is 4% of the turnover, which is a significant
      amount of money for H&M group, so the H&M group approach is to be as strict as possible for now.

- Violations of the GDPR rules must be reported within 72 hours to the Swedish Datainspektionen
      We’ve already have had at least one incident where production data was loaded into test systems and that is something that the H&M needed
      to report to the authorities. A lot of incidents like that might trigger the authorities to do an inspection, which would generate a lot
      of unnecessary work.

-  The biggest risk is not the fines, it’s the bad publicity that we might get
      A large international company like H&M is under a lot of public scrutiny. If we’re careless with customer data and some journalists
      get hold of customer data, that would most likely generate a lot of negative press. That is something we really want to avoid.

There is tons of more information about `GPDR and the implementation at H&M <https://hennesandmauritz.sharepoint.com/sites/GDPR/Pages/General-GDPR-Info.aspx>`_.

Since this is a really complex area, we really do not want you to feel forced into making these decisions on your own. Until this has become a more settled way of
working within the organization you should involve Ulf in all discussions around new uses of data and/or data exports to new groups of people. Ulf will make sure
that all the GDPR aspects are covered and get the approvals from the different DPCs before Ulf gives the go ahead. Before his approval, no persons should be given
access to the HAAL environment or any of the data there.


How HAAL ensures GDPR compliancy
--------------------------------

General Data Protection Regulation (GDPR) is a major concern for any organization storing and processing data. HAAL addresses GDPR in the following way:

-  HAAL (raw data and HDL) receives daily updates of all data from H&M source systems
-  These systems are responsible for being GDPR compliant, meaning that we rely on their implementation of data cleansing operations
-  For example data loaded from the enterprise data warehouse (“Biscuit”)


What use cases should do to stay compliant
------------------------------------------
If use cases decide to store data locally (or in Data Lake folders), they are responsible to stay compliant:

-  This entails deleting all copies of HAAL data older than 30 days
-  Best practice is to always leverage HDL for data. Do note that HDL protects against schema changes
