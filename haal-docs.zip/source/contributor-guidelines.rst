Contributor Guidelines
======================

-  Clone or fetch the latest version of the repository.
-  Update submodules.
-  Add you contributions.
-  Before committing your contributions, build locally.
-  Observe build warnings, and fix them.
-  Make sure the output is correct by browsing the generated pages
   locally.

Submodules
----------

The `docs` repository uses `git submodules` to gather content from multiple repos.

.. WARNING:: Pay attention to the instructions below to make sure you have the latest changes for the submodules


1. Clone the docs repo:

   .. code-block:: bash

      git clone ssh://git@bitbucket.hm.com:7999/haal/docs.git

2. Get the latest changes for `docs`

   .. code-block:: bash

      cd docs
      git pull

3. Get the latest for submodules, recursively

   .. code-block:: bash

      git submodule update --recursive --remote
