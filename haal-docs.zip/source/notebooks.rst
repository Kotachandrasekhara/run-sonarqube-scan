Notebooks
=========

A notebook is a web-based interface to a document that contains runnable code, visualizations, and narrative text.
It is the best way to interact with HAAL data and learn more the different data domains. 

.. toctree::
   :titlesonly:
   :glob:
   
   notebooks/**