Understanding and Consuming Data
================================

Advanced Analytics projects consume data from the HAAL Data Layer (HDL). HDL has a large number of tables, which are documented according
to their relevance. While not every single table is yet documented, we welcome your feedback to improve and extend the existing content.

To see the main table groups and their descriptions, check :doc:`datafeeds`.

Consuming and interacting with HDL
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

There are several ways to deep-dive and browse the data in HAAL, briefly described below:

 - **Insight Catalogue**

      *What?* A set of web-base, interactive reports, built and updated from live metadata. It provides a rich and low-level documentation,
      which is more useful if you are already familiar with the main table groups.


      *Recommended if* you want to have a quick overview of schemas, tables and columns, and do not need to see actual data contents.
      Does not require querying skills, and contains tons of good information about the status of the loads.

      *How to access it?* Using your H&M credentials, sign-in to https://docs.aa.hmgroup.com/reports.

      .. figure:: assets/haal_insight.png
            :scale: 25%
            :target: https://docs.aa.hmgroup.com/reports

      Insight Catalogue

      .. note:: You do not need a Power BI license in order to access the reports, but you must belong to a
         valid security group. Contact `HAAL Support <mailto:haalsupport@hm.com?subject=HAAL%20Access%20to%20Insight%20Catalogue>`_
         if you need assistance.

 - **Databricks**

      *What?* An interactive, web-based suite of tools for querying big data.

      *Recommended if* you can write your own queries and you are comfortable with exploring data on your own.
      For first-use, contact haalsupport@hm.com to get access to Databricks and a quick introduction.

      *How to access it?* Using your H&M credentials, sign-in to `Databricks <https://northeurope.azuredatabricks.net/>`_ and use the *Data*
      option on the left side of the menu.

      .. figure:: assets/databricks-01.png
            :scale: 50%
            :target: https://northeurope.azuredatabricks.net/

      *How to manage it?* Using REST API, for example refer to `Cluster Management <https://bitbucket.hm.com/projects/HAAL/repos/hdl/browse/hdl/py/databricks/cluster_management.py>`_

 - **Azure Storage Explorer**

      *What?* A desktop application for reading and downloading files from the data lake.  Azure Storage Explorer looks file a file browser – there is no querying capabilities as such.

      *Recommended if* if you need to check outputs from models or see raw files from the data lake.

      *How to access it?* Download and install Azure Storage Explorer from `here <https://go.microsoft.com/fwlink/?LinkId=708343&clcid=0x409>`_ and check the setup instructions from the official documentation `Connect to an Azure Subscription <https://docs.microsoft.com/en-us/azure/vs-azure-tools-storage-manage-with-storage-explorer?tabs=windows#connect-to-an-azure-subscription>`_

      .. warning:: When you are on the H&M network you need to go to the Edit menu and select Configure Proxy and use the information below to access the data lake.

      .. figure:: assets/proxySetting.jpg
                        :scale: 50%

      \*How to access Azure Storage Explorer inside Azure Windows Domain Joined Virtual Machine ?\* See the below picture.

      \*On Windows Server 2012

      .. figure:: assets/win2012.png
                        :scale: 50%

      \*On Windows Server 2016 and later

      .. figure:: assets/win2016.png
                        :scale: 50%

      \*On MAC

      .. figure:: assets/mac.PNG
                        :scale: 50%

      \* Fix HaalDatalake access issue by changing the proxy settings as mentioned below

      .. figure:: assets/proxysettings.png
                        :scale: 50%
