.. This is a comment.
   Markdown converted to RST in order to support the links to other documents

Getting started
===============

Welcome to HAAL! This document is an introduction to our ways of working, tools, and the few administrative procedures
required to get you started.
The audience of this page is all personnel joining the xAI initiatives.

.. warning:: Before getting started make sure to read the :doc:`security` document. It is every team member's
 responsibilities to follow the guidelines. In case of doubt, raise the issue to your peers and project leaders.


How to contact HAAL
-------------------

The preferred way to submit service and feature requests to HAAL is by using JIRA. You find detailed instructions
in the page :doc:`requests`.

To file an incident, please refer to :doc:`incidents`.


Intro to HAAL training
----------------------

HAAL offers two trainings to help onboard new team members. A generic training for all in the AI function and one targeted
for the technical HAAL users. We highly recommend taking one of them shortly after joining.

Securing your spot can be done by sending an email to `Half <mailto:half.scheidl@hm.com>`_. Below you can find the materials
that will be leveraged in the training, for your future reference. Note, HAAL SharePoint access required.

* `Intro to HAAL for non-tech <https://hennesandmauritz.sharepoint.com/sites/HAAL/Shared%20Documents/700%20Public/HAAL_Intro_to_HAAL_Non_Tech.pdf>`_
* `Intro to HAAL for tech <https://hennesandmauritz.sharepoint.com/sites/HAAL/Shared%20Documents/700%20Public/HAAL_Intro_to_HAAL_Tech.pdf>`_


Ways of working
---------------

The projects are run in Agile way, mostly following the Scrum methodology. Every team member should be familiar with
Scrum.

.. TIP:: The bare minimum requirements is to at least read the `Scrum primer <http://scrumprimer.org/scrumprimer20.pdf>`_ -
    also a great reading to remind us of the essentials of scrum and the agile mindset.
