.. Note for technical team: To generate a DOCX or PDF version of this document,
   make sure you have pandoc installed, then using a console, navigate to \docs\source\modules\HAAL
   and run the command
   pandoc -i activedirectoryaccount.rst selfservice.rst -o c:\temp\account.docx --toc --reference-doc assets/custom-reference.docx
   or
   pandoc -i activedirectoryaccount.rst selfservice.rst -o c:\temp\account.pdf --toc
   Replace c:\temp with the folder of your choice

:Title: H&M Account Setup Guide

H&M Account Setup Guide
=======================

An H&M account is required to access all IT tools and services within the project. This document is a guide to
request and activate your H&M Active Directory (AD) account.

.. NOTE:: It is highly recommended to also complete the setup for :doc:`selfservice`. Please note that account passwords are automatically
          reset every 3 months. **If you are only using VMs, you will not be prompted to change password before expiry**.

.. contents::
        :local:

Submit new account request (by Project Lead)
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

The designated use case lead submits a JIRA request for a new H&M account.

.. important:: Refer to the :doc:`boarding` for all details on onboarding a team member

This process might take up to two days, but it is usually done in a couple of hours.
Once the account has been created, HAAL will e-mail the new team member with further instructions (see below).

Set up your account (by New User)
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Depending on your needs, a few additional steps are required. Each section starts with a short description why you might need this.

.. important:: Setup at least your H&M Office365 account

1. H&M Office365 account
------------------------

Required for online access to H&M Office 365 tools: Outlook, SharePoint, Teams...

-  Once 'New user account for HAAL' email received, go to https://portal.office.com

-  Login using credentials provided:

   -  User ID in format: tempXXXXX@hm.com or firstname.lastname@hm.com
   -  Password shared via Send.BCG.com

-  Update password and register your mobile number for multi-factor authentication (MFA)

-  To use the Office 365 services

   - Login with user ID in format: tempXXXXX@hm.com, a code might be sent to your phone for MFA
   - Outlook: Go to https://outlook.office.com/
   - SharePoint: Go to https://hennesandmauritz.sharepoint.com/

-  Get access to Groups (e.g. H&M xAI), SharePoint sites (e.g. HAAL - Team Space)

   - Browse available groups, sites and request access via form
   - Alternatively, reach out to Group or Site administrator

2. Citrix Remote Desktop
------------------------

Required for remote desktop access, includes: Outlook 2013, H&M intranet and shared folders...

-  **Prerequisite:** Access to H&M email

   -  For verification purposes
   -  If access has not been granted yet and Citrix is urgently needed, ask a colleague with an H&M email

-  Call H&M IT helpdesk at +46 8 796 5901

-  Tell them you have an AD account, and need to register your cell
   number for multi-factor authentication

   -  Note: MFA setup here has to happen, independent from MFA for Office365 (see above)
   -  You can mention that Citrix Workplace is not working to help facilitate support

-  In case H&M IT helpdesk wants to verify your request:

   -  Have them send an email to your H&M address and read back the code over the phone
   -  If no access yet, provide name and email of a colleague, and have them relay the code to you

-  To use the remote desktop

   -  Go to https://workplace.hm.com
   -  Login with user ID in format: tempXXXXX, a code will be sent to your phone for MFA
   -  On first-time use: install `Citrix Receiver <https://www.citrix.com/products/receiver/>`_
   -  Click "Workplace Europe" link in the 'Desktops' tab

3. Virtual Machine
------------------
You will use a Virtual Machine (VM) provisioned in Azure for all development activities. You can
request a new VM by submitting a task to the HAAL team. Check the details in the :doc:`requests` page.

Once your request is processed, you will get an email with VM details.

.. IMPORTANT:: Read below about the temporary storage in Azure VMs.

When you create a VM in Windows Azure you are provided with a temporary
storage automatically. This temporary storage is “D:” on a Windows VM and it is “/dev/sdb1” on a Linux VM.  

.. DANGER:: This temporary storage must not be used to store data that you are not willing to lose.

.. figure:: assets/2018-08-09-17-14-52.png

    Windows VM

.. figure:: assets/2018-08-09-17-14-01.png

    Linux VM

.. note:: In any Linux distribution on Windows Azure, the sdb1 will be the
    temporary drive to be mounted. The mount point and directory mounted
    might be different between linux distributions.

The temporary storage is present on the physical machine that is hosting
your VM. Your VM can move to a different host at any point in time due
to various reasons (hardware failure etc.). When this happens your VM
will be recreated on the new host using the OS disk from your storage
account. Any data saved on the previous temporary drive will not be
migrated and you will be assigned a temporary drive on the new host.

4. Azure portal
---------------

Required to have access to the Azure portal, where all cloud services are managed incl. viewing HAAL data lake

-  Go to https://portal.azure.com and login with user ID in format: tempXXXXX@hm.com

-  Resources you have access to are listed under "All resources"

   -  By default nothing will show up
   -  Submit a new task to request access to specific resources. See :doc:`requests`.

-  Note that access to a virtual machine or Spark works separately from access
   to the Azure portal: submit a request to HAAL if you want a new resource or to be added to an existing one

-  Access to Azure Data Layer AD group can be requested from HAAL support as well. Refer to `here <https://hennesandmauritz.sharepoint.com/sites/HAAL/_layouts/15/guestaccess.aspx?guestaccesstoken=hqh8QM%2bYNgGGU5DCGHuMg0knr4trTeOZYGTEDC1pPXE%3d&docid=2_148b547268d594a8e89171c7168e4e742&rev=1>`__
   for insight in folder structure and permissions

5. Bitbucket
------------
Required to have access to H&M version control repository hosting service

-  Additional setup required

   -	Follow this link for Bitbucket access https://docs.aa.hmgroup.com/onboarding/bitbucket.html?highlight=bitbucket#bitbucket-access

-  From Citrix Remote Desktop or HAAL virtual machine

   - Go to https://bitbucket.hm.com
   -  Hit "Login" in top right, use User ID in format: tempXXXXX (consultants) or ABCDE (employees).

-  Scroll / search for required repository

   -  If you cannot find it then your setup is not complete
   -  Please submit a request using JIRA

-  Select your repository

   - Setup is similar to Github
   - Detailed instructions can be found `here <https://confluence.atlassian.com/bitbucketserver/using-bitbucket-server-776639769.html>`_

6. Direct Jira access (relevant for non-H&M employees)
------------------------------------------------------
One can access Jira from a `remote desktop <#citrix-remote-desktop>`_ or `VM <#virtual-machine>`_. This section describes how to get direct access e.g. from a non-H&M laptop, or
without being connected to the VPN.

-  Open Self Service and enter 'JIRA' in the search box and select it

  + Use https://hm.service-now.com/selfservice outside of the H&M network
  + Use http://selfservice.hm.com from inside the H&M network (remote desktop or VM)

-  Check the option 'Jira External Connection - Netscale' and click 'Next'
-  Click on the line 'Jira External Connection – Netscale' to expand the Options
-  Fill in your H&M AD account (e.g. TEMPXXYYY) in External user’s AD account'
-  Fill in 'Arti Zeighami' as the SAR
-  Check 'Jira project access'
-  Fill in your company name in 'External user is from company'
-  In other information, you can copy and paste the text: External JIRA access is needed due
    to work in remote office without access to H&M network and when VPN connectivity is limited or
    slow. This request has been previously granted to other employees in xAI function and HAAL.
-  Click 'Next', then click 'Proceed to Checkout' and click 'Checkout'

Once you click Checkout, you will receive a notification by e-mail with the request number and link to
follow-up the status of the request.
