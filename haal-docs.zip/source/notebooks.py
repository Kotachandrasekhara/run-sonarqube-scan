import os
import requests
import bs4
import base64

import sys

script_dir = os.path.dirname(__file__)
if len(sys.argv) < 3:
  print ("Please provide workspace URL and token to export Databricks notebooks.")
  sys.exit(0)

workspace = str(sys.argv[1])
auth_token = str(sys.argv[2])

hed = {"Authorization": "Bearer " + auth_token}

def html_append_css(html_content, css_file):
    soup = bs4.BeautifulSoup(html_content, features="html.parser")
    # insert it into the document
    new_css_link = soup.new_tag(
        "link", attrs={"rel": "stylesheet", "href": css_file, "type": "text/css"}
    )
    soup.head.insert(0, new_css_link)
    return str(soup)


def dbfs_get_files(dbfs_path):
    dbs_api_dbfs_list = "https://{}/api/2.0/dbfs/list".format(workspace)
    dbs_api_dbfs_read = "https://{}/api/2.0/dbfs/read".format(workspace)

    api_response_list = requests.get(dbs_api_dbfs_list, json={"path": dbfs_path}, headers=hed, verify=False)
    dbs_files = api_response_list.json()['files']
    for dbs_file in dbs_files:
        print("Exporting file from path '{}'".format(dbs_file["path"]))
        file_name = "/".join(dbs_file["path"].split("/")[-2:])
        export_path = "_static/notebooks/files/{}".format(file_name)        
        body = { 'path': dbs_file['path']}  #offset : 0 , length: 1MB
        api_response_file = requests.get(dbs_api_dbfs_read, json=body, headers=hed, verify=False)
        base64Contents_str = api_response_file.json()['data']

        
        file_path_abs = os.path.join(script_dir, export_path)
        os.makedirs(os.path.dirname(file_path_abs), exist_ok=True)
        with open(file_path_abs, "wb") as fh:
            fh.write(base64.b64decode(base64Contents_str))        


def dbfs_get_notebooks(notebook_path):
    dbs_api_workspaces = "https://{}/api/2.0/workspace/list".format(workspace)
    dbs_api_body_notebooks = {"path": notebook_path}
    notebook_url_base = "https://{}/#notebook/{{}}".format(workspace)
    notebook_export_url = lambda notebook_path: "https://{}/api/2.0/workspace/export?path={}&format=HTML&direct_download=true".format(workspace, notebook_path)
    
    api_response_notebooks = requests.get(dbs_api_workspaces, json=dbs_api_body_notebooks, headers=hed, verify=False)

    notebooks = api_response_notebooks.json()["objects"]

    for notebook in notebooks:
        print("Exporting notebook from path '{}'".format(notebook["path"]))
        file_name_candidate = notebook["path"].split("/")[-1]
        api_url = notebook_export_url(notebook["path"])
        notebook_url = notebook_url_base.format(notebook["object_id"])
        notebook_export_req = requests.get(api_url, headers=hed, verify=False)
        if (not notebook_export_req.ok):
            raise Exception("Error while exporting notebooks from Databricks: " + notebook_export_req.text)

        notebook_export = notebook_export_req.text
        
	
        export_path_rel = "_static/notebooks/{}.html".format(file_name_candidate)
        export_path_abs = os.path.join(script_dir, "./" + export_path_rel)
        rst_path_rel = "notebooks/{}.rst".format(file_name_candidate)
        rst_path_abs = os.path.join(script_dir, rst_path_rel)
        os.makedirs(os.path.dirname(export_path_abs), exist_ok=True)
        with open(export_path_abs, "w") as f:
            notebook_export = html_append_css(notebook_export, "../css/databricks_overrides.css")
            f.writelines(notebook_export)
        
        # Please note that identation below is important for the generate RST to be correct:
        # First {} is for the title, and second {} is for the underlines under the tile
        #  .. raw:html must not be idented!
        with open(rst_path_abs, "w") as f:
            content = """{}
{}

.. raw:: html    

    <div class="embedded-notebook">
        <p class="notebook-import-help">  
            <a target="_blank" href="https://databricks-prod-cloudfront.cloud.databricks.com/public/4027ec902e239c93eaaa8714f173bcfc/2019135542862542/584054368563718/5339565930708803/latest.html">How to clone a notebook</a>      
            <a style="float:right" target="_blank" href="{}">Open in Databricks</a>
        </p>
        <div class="embedded-notebook-container">
            <div class='loading-spinner'></div>
            <iframe data-src="../{}" height="200px" width="100%" allowfullscreen></iframe>
        </div>        
    </div>""".format(                
                        file_name_candidate,
                        "=" * len(file_name_candidate), #underscore for RST title
                        notebook_url,
                        export_path_rel
                    )            
            f.writelines(content)

            

try:
    
    dbfs_get_files("dbfs:/FileStore/images/")       
    dbfs_get_notebooks("/Docs")
    
except Exception as error:
    print("Something went wrong while exporting Databricks notebooks!")
    print(error)
    sys.exit(-1)
