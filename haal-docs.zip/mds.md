### In-store Store Markdown Optimization

This package optimizers in-store markdown pricing.

#### Documenation

##### [Getting started](documentation/getting-started.md)

Which problem does the MDS AA model try to solve?, What are the building
blocks of the model? How is the model's environment designed? How do I
run the model?

##### [Infrastructure](lib/store_markdown/README.md)

What is infrastructure is the model embedded in? Which tools are we
using (HAAL, Spar Cluster, DSVM, Airflow)?

##### [ETL](lib/store_markdown/etl/README.md)

What is the ETL process, i.e, what are we doing to the source data to
prepare it for AA?

##### [Virtual Data Layer](lib/store_markdown/modules/s010_virtual_layer/README.md)

How is the interface between the source data and the model designed?

##### [Demand predictor](lib/store_markdown/modules/s020_demand_predictor/README.md)

Which method do we use to predict demand?

##### [Stock corrector](lib/store_markdown/modules/s021_stock_corrector/README.md)

How do we obtain the latest stock data?

##### [Optimizer](lib/store_markdown/modules/s040_optimizer/README.md)

Which optimization problem are we trying to solve? Which constraints do
we have? What is the architecture of the optimizer? How do we simulate
stock and sales?

##### [Read & React](lib/store_markdown/modules/s050_read_react/README.md)

How do we adjust our predictions during the sale period?

##### Model output

How do we generate client-ready model output for the client?
